# Med Lend

A website where patients get advice from a doctor about the medical equipment they need at home, then borrow it from the clinic's equipment desk.

There are three kinds of account:

| Account | Who | What they do |
| --- | --- | --- |
| **Patient** | Signs up on the site | Describes their condition to a doctor, requests equipment, sees their loans |
| **Doctor** | Added by the admin | Answers the patient issues assigned to them, with advice and recommended equipment |
| **Admin** (equipment desk) | Created when the database is first made | Assigns issues to doctors, approves requests, records returns, manages equipment, patients and doctors |

## How it works

1. **A patient describes an issue**: a short title, who it is for (themselves or a family member, which asks for the patient's name), how soon they need help, and the condition.
2. **The admin assigns a doctor**, choosing one whose specialty fits.
3. **The doctor replies** with advice and ticks the equipment that will help. The patient sees each item with its stock and can request it in one click. The conversation can continue until the patient or the admin closes the issue.
4. **The patient requests the equipment.** One unit is held for them while the admin approves or declines (with a reason).
5. **The admin records the return.** A unit returned damaged or needing repair goes to repair instead of back into stock.

**Stock:** each item has a number of units owned. Units in stock = owned − in repair − requested − on loan, worked out from the loans every time. Every page shows "3 in stock" or "Out of stock", and out-of-stock items cannot be requested.

**Other rules:** each patient can have up to 3 items at a time, including requests. Anyone with overdue equipment cannot borrow more. Suspended accounts cannot sign in.

**Photos:** the admin can upload a photo for each item (JPG, PNG or WebP, up to 2 MB) on the Equipment page. Until then, a drawing for the item's category is shown. Use your own photos, or free ones from a site such as [Pexels](https://www.pexels.com) or [Unsplash](https://unsplash.com), whose licences allow this.

**Starting data:** the database starts with the admin, one doctor and 29 items (108 units). There are no patients, issues or loans until real people create them, so the dashboard starts at zero.

## Sign-in details

| Account | Username | Password |
| --- | --- | --- |
| Admin (Nadia Farouk) | `admin` | `MedLend2026!` |
| Doctor (Dr. Karim Mansour, Orthopaedics) | `dr.karim` | `Doctor2026!` |

To change these before the first start, set `ADMIN_NAME`, `ADMIN_USERNAME`, `ADMIN_PASSWORD` and `DOCTOR_PASSWORD`. More doctors are added on the Doctors page.

## Running it on your computer

1. Install **Node.js 22.13 or newer** from https://nodejs.org (Node 24 is recommended).
2. In the project folder, run:

   ```bash
   npm install
   npm start
   ```

3. Open http://localhost:3000

There are no packages to download. The server and the SQLite database both use what comes with Node.

| Command | What it does |
| --- | --- |
| `npm start` | Starts the website |
| `npm test` | Runs the automated tests |
| `npm run reset-db` | Deletes the database (stop the server first). A new one is made on the next start. |

## Equipment photos

There are two ways to add real photos:

1. **One at a time:** sign in as the admin, open Equipment, click Edit on an item and choose a photo.
2. **All at once:** put the photos in the `photos/` folder, named as listed in `photos/README.txt`
   (for example `walking-frame.jpg`), then restart with `npm start`. Each photo is added to its item
   if that item has no photo yet.

Use photos you are allowed to use (your own, or free-licence ones from Wikimedia Commons, Pexels or Unsplash).

## How to use each item

Every item has short "How to use" steps that patients can open on Borrow equipment and My loans.
The starting steps are in `server/how-to-use.js`. The admin can change them for any item on the Equipment page (Edit).

## Database

- SQLite file at `data/medlend.db`, created automatically the first time you start the app.
- Tables: `users` (all three roles), `sessions`, `equipment`, `photos`, `loans`, `issues`, `issue_messages`, `recommendations`.
- Passwords are hashed with scrypt and never stored as plain text. Sign-ins are stored in `sessions`, so they survive a restart, and last 7 days.
- Photos are stored in the database, so a backup of the one file keeps everything.
- A database from an older version of Med Lend is renamed to `medlend.db.old` and a fresh one is created.
- Set `DB_PATH` to keep the database somewhere else.

## Folder structure

```
medlend/
├── server/
│   ├── server.js     starts the server, serves pages and photos, checks who can see what
│   ├── api.js        every API route and the rules (issues, stock, requests, returns…)
│   └── db.js         creates the tables, the first accounts and the equipment list
├── public/
│   ├── login.html, register.html                         sign in and sign up
│   ├── accessibility.html                                accessibility statement and how we test (open to everyone)
│   ├── feedback.html, feedback-admin.html                 send feedback (anyone) and read it (admin)
│   ├── borrow.html, my-loans.html                        patient pages
│   ├── dashboard.html, equipment.html, loans.html,
│   │   patients.html, doctors.html                       admin pages
│   ├── issues-*.html, issue-*.html, account-*.html       shared pages, one copy per role because the menu differs
│   ├── css/styles.css
│   ├── img/equipment/  a drawing for each equipment category
│   └── js/           one file per page, plus main.js and account-status.js for shared code
├── tests/api.test.js
└── data/             the database file goes here
```

## Deployment

The live site is at **https://www.medlend.website**.

- **Server:** a Vultr cloud server running Ubuntu.
- **App:** Node.js runs `npm start` as a background service, so the site restarts automatically if it crashes or the server reboots.
- **Database:** SQLite, stored on the server, so data is kept after restarts.
- **Web server:** Nginx receives visitors and passes requests to the app on port 3000.
- **HTTPS:** a free Let's Encrypt certificate. Nginx redirects every `http://` visit to `https://`.
- **Domain:** registered with Namecheap, with A records pointing to the server's IP address.

The server marks the sign-in cookie as Secure automatically when Nginx reports the visit came over HTTPS (the `X-Forwarded-Proto` header).

## Accessibility (WCAG 2.1 AA)

- Proper headings, landmarks, a "Skip to main content" link and a clear focus outline.
- Every field has a visible label. Errors appear in a list at the top of the form, with links to each field, and next to the field itself. Whatever was typed is kept.
- Success and error messages are announced by screen readers.
- Status badges use an icon and a word, never colour alone. Text colours meet 4.5:1 contrast.
- Pop-up forms use the native `<dialog>` element: Escape closes them and focus goes back to the button you pressed.
- Works on phones and at 200% zoom. On small screens the menu becomes a button.
- Extra fields appear only when needed: the patient's name when asking for a family member, a delivery address for home-care loans, repair notes when units are in repair, and "what is wrong with it" for damaged returns.
- Messages in an issue are a list of articles with the author and time; equipment photos are decorative (the name is next to them), so they have empty alt text.
