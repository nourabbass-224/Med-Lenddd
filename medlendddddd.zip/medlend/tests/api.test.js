// API tests. Run with: npm test
const test = require('node:test');
const assert = require('node:assert/strict');
const createServer = require('../server/server');

let server;
let base;

// A tiny client that keeps its own session cookie, like a browser would.
// Form problems come back as 200 with ok: false; they are reported as status 400 here so the tests read clearly.
function client() {
  let cookie = '';
  return async (method, url, body) => {
    const res = await fetch(base + url, {
      method,
      headers: { 'Content-Type': 'application/json', Cookie: cookie },
      body: body ? JSON.stringify(body) : undefined,
      redirect: 'manual'
    });
    const setCookie = res.headers.get('set-cookie');
    if (setCookie) cookie = setCookie.split(';')[0];
    const type = res.headers.get('content-type') || '';
    const data = type.includes('json') ? await res.json() : null;
    const status = data && data.ok === false && res.status === 200 ? 400 : res.status;
    return { status, data, location: res.headers.get('location'), type };
  };
}

const admin = client();
const doctor = client();
const sara = client();
const visitor = client();

// local date, the same way the server works it out
const today = new Date(Date.now() - new Date().getTimezoneOffset() * 60000).toISOString().slice(0, 10);
const inDays = (n) => new Date(Date.now() + n * 86400000).toISOString().slice(0, 10);
const item = async (name) => (await admin('GET', '/api/equipment?search=' + encodeURIComponent(name))).data[0];

test.before(async () => {
  server = createServer(':memory:');
  await new Promise((resolve) => server.listen(0, resolve));
  base = `http://localhost:${server.address().port}`;
});
test.after(() => server.close());

test('pages and API are protected', async () => {
  assert.equal((await visitor('GET', '/dashboard')).location, '/');
  assert.equal((await visitor('GET', '/issues')).location, '/');
  assert.equal((await visitor('GET', '/api/equipment')).status, 401);
});

test('a new database has stock but no patients, issues or loans', async () => {
  assert.equal((await admin('POST', '/api/login', { username: 'admin', password: 'MedLend2026!' })).status, 200);
  const { data } = await admin('GET', '/api/dashboard');
  assert.equal(data.counts.items, 29);
  assert.ok(data.counts.units > 80);
  assert.equal(data.counts.on_loan, 0);
  assert.equal(data.counts.patients, 0);
  assert.equal(data.counts.new_issues, 0);
  const bariatric = await item('Bariatric');
  assert.equal(bariatric.in_stock, 0, 'the only bariatric wheelchair is in repair');
});

test('patients register; doctors sign in and land on their issues page', async () => {
  const bad = await visitor('POST', '/api/register', { full_name: '', gender: 'x', phone: '123', username: 'a', password: 'short' });
  for (const field of ['full_name', 'gender', 'phone', 'username', 'password']) assert.ok(bad.data.fields[field], field);
  assert.equal((await sara('POST', '/api/register', {
    full_name: 'Sara Ali', gender: 'Female', phone: '010 1234 5678', username: 'sara_ali', password: 'pass1234', confirm_password: 'pass1234'
  })).status, 200);
  assert.equal((await doctor('POST', '/api/login', { username: 'dr.karim', password: 'Doctor2026!' })).data.role, 'doctor');
  assert.equal((await doctor('GET', '/dashboard')).location, '/issues');
  assert.equal((await sara('GET', '/api/dashboard')).status, 403);
});

test('issue flow: patient asks, admin assigns, doctor answers with equipment, patient follows up', async () => {
  const bad = await sara('POST', '/api/issues', { subject: 'Hi', details: 'short', for_whom: 'A family member', urgency: 'x' });
  for (const f of ['subject', 'details', 'patient_name', 'urgency']) assert.ok(bad.data.fields[f], f);

  const made = await sara('POST', '/api/issues', {
    subject: 'Mother had a hip replacement',
    details: 'My mother is 72 and came home after hip surgery. She cannot walk far and struggles to get out of bed.',
    for_whom: 'A family member', patient_name: 'Fatma Ali', urgency: 'Within a few days'
  });
  const id = made.data.id;
  assert.equal((await doctor('GET', `/api/issues/${id}`)).status, 404, 'not assigned yet');

  const doctors = (await admin('GET', '/api/doctors')).data;
  await admin('POST', `/api/issues/${id}/assign`, { doctor_id: doctors[0].id });
  assert.equal((await doctor('GET', '/api/issues')).data.length, 1);

  const frame = await item('Walking frame');
  const bed = await item('Electric hospital bed');
  await doctor('POST', `/api/issues/${id}/messages`, {
    message: 'A walking frame for the first weeks and an electric bed will help her get up safely.',
    equipment_ids: [frame.id, bed.id]
  });
  const seen = (await sara('GET', `/api/issues/${id}`)).data;
  assert.equal(seen.status, 'Answered');
  assert.equal(seen.messages[0].recommended.length, 2);
  assert.equal(seen.messages[0].recommended[0].in_stock > 0, true);

  await sara('POST', `/api/issues/${id}/messages`, { message: 'Thank you. Does the bed need to be delivered?' });
  assert.equal((await sara('GET', `/api/issues/${id}`)).data.status, 'With doctor');
  assert.equal((await admin('POST', `/api/issues/${id}/messages`, { message: 'hello' })).status, 403);
});

test('stock goes down with requests and loans, and out of stock cannot be requested', async () => {
  const ecg = await item('Portable ECG');
  assert.equal(ecg.in_stock, 1);
  assert.equal((await sara('POST', '/api/my-loans', { equipment_id: ecg.id, due_date: inDays(10), purpose: 'Home use' })).status, 200);
  assert.equal((await item('Portable ECG')).in_stock, 0);
  const again = await sara('POST', '/api/my-loans', { equipment_id: ecg.id, due_date: inDays(10), purpose: 'Home use' });
  assert.match(again.data.error, /out of stock/);
  const outOfStock = (await admin('GET', '/api/equipment?stock=Out of stock')).data.map((e) => e.name);
  assert.ok(outOfStock.includes('Portable ECG monitor') && outOfStock.includes('Bariatric wheelchair'));

  const request = (await admin('GET', '/api/loans?status=Requested')).data[0];
  assert.equal((await admin('POST', `/api/loans/${request.id}/approve`)).status, 200);
  const mine = (await sara('GET', '/api/my-loans')).data;
  assert.equal(mine[0].status, 'On loan');
});

test('a damaged return moves one unit to repair', async () => {
  const loan = (await admin('GET', '/api/loans?status=On loan')).data[0];
  const needsNotes = await admin('POST', `/api/loans/${loan.id}/return`, { return_date: today, return_condition: 'Damaged' });
  assert.ok(needsNotes.data.fields.return_notes);
  await admin('POST', `/api/loans/${loan.id}/return`, { return_date: today, return_condition: 'Damaged', return_notes: 'Screen cracked' });
  const ecg = await item('Portable ECG');
  assert.equal(ecg.in_repair, 1);
  assert.equal(ecg.in_stock, 0);
  assert.match(ecg.repair_notes, /Screen cracked/);
});

test('equipment: quantity rules, photo upload and delete', async () => {
  const bad = await admin('POST', '/api/equipment', { name: '', quantity: 0, in_repair: 0 });
  assert.ok(bad.data.fields.name && bad.data.fields.category && bad.data.fields.quantity);
  const repairNotes = await admin('POST', '/api/equipment', { name: 'Test cane', category: 'Mobility aids', quantity: 2, in_repair: 1 });
  assert.ok(repairNotes.data.fields.repair_notes);

  // a 1x1 PNG
  const png = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==';
  const badPhoto = await admin('POST', '/api/equipment', { name: 'Test cane', category: 'Mobility aids', quantity: 2, photo: { type: 'image/gif', data: png } });
  assert.ok(badPhoto.data.fields.photo);
  assert.equal((await admin('POST', '/api/equipment', {
    name: 'Test cane', category: 'Mobility aids', quantity: 2, in_repair: 0, photo: { type: 'image/png', data: png }
  })).status, 200);
  const cane = await item('Test cane');
  assert.ok(cane.photo_version > 0);
  const photo = await visitor('GET', `/photos/${cane.id}`);
  assert.equal(photo.status, 200);
  assert.equal(photo.type, 'image/png');

  await admin('PUT', `/api/equipment/${cane.id}`, { ...cane, quantity: 3, remove_photo: true });
  const edited = await item('Test cane');
  assert.equal(edited.quantity, 3);
  assert.equal(edited.photo_version, 0);
  assert.equal((await admin('DELETE', `/api/equipment/${cane.id}`)).status, 200);
});

test('admin adds a doctor and can suspend accounts', async () => {
  const bad = await admin('POST', '/api/doctors', { full_name: 'X', username: 'dr.karim', password: 'x' });
  assert.ok(bad.data.fields.username && bad.data.fields.specialty && bad.data.fields.password);
  await admin('POST', '/api/doctors', {
    full_name: 'Dr. Heba Youssef', gender: 'Female', phone: '01223334455', specialty: 'Respiratory medicine', username: 'dr.heba', password: 'Heba2026x'
  });
  assert.equal((await visitor('POST', '/api/login', { username: 'dr.heba', password: 'Heba2026x' })).data.role, 'doctor');

  const patient = (await admin('GET', '/api/patients')).data[0];
  await admin('PUT', `/api/accounts/${patient.id}/status`, { active: false });
  assert.equal((await sara('GET', '/api/me')).status, 401);
  assert.match((await sara('POST', '/api/login', { username: 'sara_ali', password: 'pass1234' })).data.error, /suspended/);
  await admin('PUT', `/api/accounts/${patient.id}/status`, { active: true });
  assert.equal((await sara('POST', '/api/login', { username: 'sara_ali', password: 'pass1234' })).status, 200);
});

test('my account: update details and change password', async () => {
  assert.ok((await sara('PUT', '/api/profile', { full_name: 'Sara Ali', gender: 'Female', phone: '999' })).data.fields.phone);
  const wrong = await sara('PUT', '/api/profile/password', { current_password: 'nope', new_password: 'newpass99', confirm_new_password: 'newpass99' });
  assert.ok(wrong.data.fields.current_password);
  assert.equal((await sara('PUT', '/api/profile/password', { current_password: 'pass1234', new_password: 'newpass99', confirm_new_password: 'newpass99' })).status, 200);
  assert.equal((await sara('GET', '/api/me')).status, 200);
});

test('patients close their issues; logout ends the session', async () => {
  const issue = (await sara('GET', '/api/issues')).data[0];
  assert.equal((await doctor('POST', `/api/issues/${issue.id}/close`)).status, 403);
  await sara('POST', `/api/issues/${issue.id}/close`);
  assert.equal((await sara('GET', `/api/issues/${issue.id}`)).data.status, 'Closed');
  await sara('POST', '/api/logout');
  assert.equal((await sara('GET', '/api/me')).status, 401);
});

test('feedback: anyone can send it, only the admin can read it', async () => {
  const guest = client(); // not signed in
  const empty = await guest('POST', '/api/feedback', {});
  assert.ok(empty.data.fields.name && empty.data.fields.topic && empty.data.fields.message);
  assert.equal((await guest('POST', '/api/feedback', { name: 'Omar', topic: 'Suggestion', message: 'Please add a dark mode.' })).status, 200);
  assert.equal((await doctor('POST', '/api/feedback', { topic: 'Accessibility problem', page: 'Patient issues', message: 'Focus is hard to see on the menu.' })).status, 200);

  assert.equal((await guest('GET', '/api/feedback')).status, 401);
  assert.equal((await doctor('GET', '/api/feedback')).status, 403);
  const all = (await admin('GET', '/api/feedback')).data;
  assert.equal(all.length, 2);
  assert.ok(all.some((f) => f.name === 'Dr. Karim Mansour' && f.role === 'doctor'));
  assert.equal((await admin('GET', '/api/dashboard')).data.counts.new_feedback, 2);

  await admin('PUT', `/api/feedback/${all[0].id}/status`, { status: 'Dealt with' });
  assert.equal((await admin('GET', '/api/feedback?status=New')).data.length, 1);
  assert.equal((await guest('GET', '/feedback')).status, 200);
});
