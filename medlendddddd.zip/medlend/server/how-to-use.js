// Simple "how to use" steps for each item, shown to patients on the Borrow and My loans pages.
// One string per step. The admin can change them on the Equipment page.
// These are general instructions: patients should always follow what their doctor or therapist told them.
module.exports = {
  'Standard wheelchair': [
    'Open the chair by pressing down on both sides of the seat until it is flat.',
    'Put both brakes on before sitting down or getting up.',
    'Fold the footrests up to sit, then down to rest your feet on them.',
    'Take the brakes off and push the big wheels with your hands to move.',
    'Go down kerbs and slopes backwards, or with a helper.'
  ],
  'Transit wheelchair': [
    'This chair is pushed by a helper; the person sitting cannot move it alone.',
    'The helper puts the brakes on (levers on the handles) before the person sits down or stands up.',
    'Check the person\'s feet are on the footrests before moving.',
    'Push at walking pace and tilt back slightly to go up a kerb.'
  ],
  'Bariatric wheelchair': [
    'Check the weight limit on the label (up to 220 kg) before use.',
    'Put both brakes on before sitting down or getting up.',
    'Sit back fully in the wide seat and rest your feet on the footrests.',
    'Use a helper on slopes; the chair is heavier than a standard one.'
  ],
  'Four-wheel rollator': [
    'Set the handles to wrist height while standing straight with your arms by your sides.',
    'Walk inside the frame, not behind it, and keep it close to you.',
    'Squeeze the brake levers to slow down.',
    'Before sitting on the seat, push the brakes down until they click to lock them.',
    'Never use the seat to push someone along.'
  ],
  'Walking frame': [
    'Set the height so the handles are level with your wrists.',
    'Lift or slide the frame one step in front of you, with all four feet on the ground.',
    'Step forward with your weaker or injured leg first, then your stronger leg.',
    'Do not lean too far forward or use it on stairs.'
  ],
  'Elbow crutches (pair)': [
    'Set the height so the handle is at your wrist with your elbow slightly bent.',
    'Put your arms through the cuffs and hold the handles.',
    'Move both crutches forward, then step through with the injured leg, then the good leg.',
    'On stairs: going up, good leg first; going down, crutches and injured leg first.'
  ],
  'Quad walking stick': [
    'Hold the stick in the hand on the side opposite your weaker leg.',
    'Set the height so the handle is at your wrist when your arm hangs down.',
    'Place the stick forward with all four feet flat on the ground.',
    'Step forward with your weaker leg, then your stronger leg.'
  ],
  'Portable oxygen concentrator': [
    'Use only the setting your doctor prescribed. Do not change it yourself.',
    'Charge the battery fully before going out, and carry the spare.',
    'Put the nasal tube in your nose and loop it over your ears, then switch on.',
    'Keep it away from smoking, cooking flames and heaters.'
  ],
  'Home oxygen concentrator': [
    'Place it at least 30 cm from walls and curtains so air can flow, away from heaters and flames.',
    'Fill the humidifier bottle with water up to the line if one is fitted.',
    'Switch on and set the flow to the number your doctor prescribed.',
    'Put the nasal tube in your nose. Never smoke or allow open flames in the room.',
    'Wash the filter every week.'
  ],
  'Compressor nebuliser': [
    'Wash your hands, then put the prescribed medicine into the medicine cup.',
    'Attach the mouthpiece or mask and connect the tube to the machine.',
    'Sit upright, switch on, and breathe slowly through your mouth until the mist stops (about 10 minutes).',
    'Wash the cup and mouthpiece in warm soapy water and let them dry.'
  ],
  'CPAP machine': [
    'Fill the water tank with distilled or boiled and cooled water up to the line.',
    'Put on the mask and tighten the straps until it seals without being tight.',
    'Lie down and switch on; the machine sets the pressure your doctor prescribed.',
    'Wash the mask every day and empty the water tank each morning.'
  ],
  'Suction machine': [
    'This machine is for carers who have been shown how to use it by a nurse.',
    'Connect a clean catheter to the tube and switch on.',
    'Check the suction with your thumb over the hole, then suction gently for no more than 10 to 15 seconds.',
    'Empty and clean the collection jar every day. Keep the battery charged.'
  ],
  'Pulse oximeter': [
    'Rest for 5 minutes and warm your hands. Remove nail polish from the finger you use.',
    'Open the clip and put your finger in, nail facing up.',
    'Keep still and wait until the numbers stop changing (about 30 seconds).',
    'SpO2 is your oxygen level and PR is your pulse. Call your doctor if the oxygen level is lower than they told you.'
  ],
  'Blood pressure monitor': [
    'Sit quietly for 5 minutes with your back supported and feet flat on the floor.',
    'Put the cuff on your bare upper arm, about 2 cm above the elbow, at heart level.',
    'Press Start and keep still and quiet until it finishes.',
    'Write down the top number, the bottom number and your pulse. Take readings at the same time each day.'
  ],
  'Blood glucose meter': [
    'Wash and dry your hands. Put a test strip in the meter.',
    'Use the lancing device on the side of a fingertip.',
    'Touch the drop of blood to the end of the strip and wait for the result.',
    'Write down the result and throw away the strip and lancet safely.'
  ],
  'Portable ECG monitor': [
    'Your doctor or nurse will show you where the sticky pads go on your chest.',
    'Clean and dry the skin, stick the pads on and clip on the leads by colour.',
    'Switch on and choose New record. Keep still and breathe normally.',
    'Press Mark if you feel symptoms, and bring the monitor back as arranged.'
  ],
  'Mobile patient hoist': [
    'Only use the hoist if you have been trained. Two people are usually needed.',
    'Roll the person onto the sling and attach the sling loops to the hoist bar.',
    'Open the legs of the hoist for stability and press Up slowly.',
    'Move the hoist with the brakes off, then lower the person gently onto the bed or chair.'
  ],
  'Standing hoist': [
    'The person must be able to bear some weight on their legs and hold the handles.',
    'Place their feet on the footplate and knees against the knee pads.',
    'Fit the belt around their back, then press Up slowly to help them stand.',
    'Move to the chair or toilet and press Down to lower them.'
  ],
  'Transfer board': [
    'Put the brakes on the wheelchair and remove the armrest on the transfer side.',
    'Place the board under the thigh, bridging the bed and the chair.',
    'Slide across in small movements, using your hands to push.',
    'Do not lift or hold the board while someone is sitting on it.'
  ],
  'Slide sheet set': [
    'Roll the person slightly and place both sheets underneath them, smooth sides together.',
    'Hold the top sheet and slide it in the direction you want to move them.',
    'Use two carers when possible, and bend your knees, not your back.',
    'Always remove the slide sheets afterwards so the person does not slip.'
  ],
  'Electric hospital bed': [
    'Use the handset buttons to raise the back, the knees or the whole bed.',
    'Lower the bed to its lowest height when the person is resting.',
    'Lock the wheel brakes before anyone gets in or out.',
    'Keep the cable and handset clear of the moving parts.'
  ],
  'Pressure relief mattress': [
    'Lay the air mattress on the bed with the tubes at the foot end.',
    'Connect the tubes to the pump and switch it on. Wait 30 minutes until it is fully inflated.',
    'Cover it with one thin sheet only.',
    'Do not switch the pump off while someone is lying on it.'
  ],
  'Overbed table': [
    'Roll the table so the base fits under the bed or chair.',
    'Hold the lever and lift or lower the top to the right height.',
    'Do not lean on it or use it to help stand up; it can roll away.'
  ],
  'Bed rails (pair)': [
    'Slide the rails under the mattress, one on each side, and tighten the straps.',
    'Check there is no gap between the rail and the mattress where an arm or head could get stuck.',
    'Raise the rails when the person is resting and lower them to help them out of bed.'
  ],
  'Shower chair': [
    'Set all four legs to the same height so the chair does not rock.',
    'Make sure all the rubber feet are firmly on the shower floor.',
    'Hold the armrests to sit down and stand up slowly.',
    'Dry the chair after use.'
  ],
  'Raised toilet seat': [
    'Set the legs so the frame stands level over the toilet.',
    'Check the seat sits firmly and does not move before using it.',
    'Hold both armrests to lower yourself and to stand up.',
    'Clean it with normal toilet cleaner.'
  ],
  'Commode chair': [
    'Place the commode next to the bed and push the brakes down if it has wheels.',
    'Lift the seat lid and check the pot is in place.',
    'Hold the armrests to sit down and stand up.',
    'Empty and clean the pot after each use.'
  ],
  'Knee CPM machine': [
    'Your physiotherapist will set the angle and speed. Do not change them yourself.',
    'Lie on your back and rest your leg on the support, with the knee at the hinge.',
    'Fasten the straps and press Start. The machine bends and straightens your knee slowly.',
    'Stop and call your physiotherapist if the pain is getting worse.'
  ],
  'Pedal exerciser': [
    'Put it on the mat in front of a chair that will not move.',
    'Sit upright and put your feet in the pedals, then tighten the straps.',
    'Start with low resistance for 5 to 10 minutes and pedal slowly.',
    'It can go on a table to exercise your arms. Stop if you feel pain or dizziness.'
  ]
};
