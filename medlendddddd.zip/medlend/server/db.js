// Database setup. Uses the SQLite module that comes with Node (version 22.13 or newer).
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { DatabaseSync } = require('node:sqlite');
const HOW_TO_USE = require('./how-to-use');

const DB_FILE = process.env.DB_PATH || path.join(__dirname, '..', 'data', 'medlend.db');
const SCHEMA_VERSION = 3;

// Passwords are stored as "salt:hash", never as plain text.
function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return salt + ':' + hash;
}

function checkPassword(password, stored) {
  const [salt, hash] = stored.split(':');
  const attempt = crypto.scryptSync(password, salt, 64).toString('hex');
  return crypto.timingSafeEqual(Buffer.from(attempt, 'hex'), Buffer.from(hash, 'hex'));
}

const tables = `
  -- role: admin (equipment desk), doctor (answers patient issues) or user (patient)
  CREATE TABLE IF NOT EXISTS users (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    full_name     TEXT NOT NULL,
    username      TEXT NOT NULL UNIQUE COLLATE NOCASE,
    password_hash TEXT NOT NULL,
    gender        TEXT NOT NULL,
    phone         TEXT NOT NULL,
    role          TEXT NOT NULL CHECK (role IN ('admin', 'doctor', 'user')),
    specialty     TEXT NOT NULL DEFAULT '',
    active        INTEGER NOT NULL DEFAULT 1,  -- 0 = suspended by the admin
    created_at    TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS sessions (
    token      TEXT PRIMARY KEY,
    user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    expires_at INTEGER NOT NULL
  );

  -- quantity = how many units the clinic owns; in_repair = units that cannot be lent.
  -- Units in stock = quantity - in_repair - units requested or on loan (worked out in api.js).
  CREATE TABLE IF NOT EXISTS equipment (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    name          TEXT NOT NULL,
    category      TEXT NOT NULL,
    description   TEXT NOT NULL DEFAULT '',
    quantity      INTEGER NOT NULL CHECK (quantity >= 0),
    in_repair     INTEGER NOT NULL DEFAULT 0,
    repair_notes  TEXT NOT NULL DEFAULT '',
    how_to_use    TEXT NOT NULL DEFAULT '',   -- steps, one per line
    photo_version INTEGER NOT NULL DEFAULT 0,  -- 0 = no photo; changes on every upload
    date_added    TEXT NOT NULL
  );

  -- One photo per equipment item, stored in the database so it is backed up with everything else
  CREATE TABLE IF NOT EXISTS photos (
    equipment_id INTEGER PRIMARY KEY REFERENCES equipment(id) ON DELETE CASCADE,
    mime         TEXT NOT NULL,
    data         BLOB NOT NULL
  );

  -- state: requested -> active -> returned, or requested -> declined / cancelled.
  -- For a request, loan_date is the day it was requested; it changes to the approval day.
  CREATE TABLE IF NOT EXISTS loans (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id          INTEGER NOT NULL REFERENCES users(id),
    equipment_id     INTEGER NOT NULL,
    equipment_name   TEXT NOT NULL,   -- copied so old loans keep a name if the item is deleted
    loan_date        TEXT NOT NULL,
    due_date         TEXT NOT NULL,
    return_date      TEXT,
    purpose          TEXT NOT NULL,
    delivery_address TEXT NOT NULL DEFAULT '',
    return_condition TEXT NOT NULL DEFAULT '',
    return_notes     TEXT NOT NULL DEFAULT '',
    state            TEXT NOT NULL DEFAULT 'active',
    decline_reason   TEXT NOT NULL DEFAULT ''
  );

  -- A patient describes their condition; the admin assigns a doctor, who replies.
  -- status: New (no doctor yet) -> With doctor -> Answered -> Closed
  CREATE TABLE IF NOT EXISTS issues (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id      INTEGER NOT NULL REFERENCES users(id),
    doctor_id    INTEGER REFERENCES users(id),
    subject      TEXT NOT NULL,
    details      TEXT NOT NULL,
    for_whom     TEXT NOT NULL,
    patient_name TEXT NOT NULL DEFAULT '',
    urgency      TEXT NOT NULL,
    status       TEXT NOT NULL DEFAULT 'New',
    created_at   TEXT NOT NULL,
    updated_at   TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS issue_messages (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    issue_id   INTEGER NOT NULL REFERENCES issues(id) ON DELETE CASCADE,
    author_id  INTEGER NOT NULL REFERENCES users(id),
    body       TEXT NOT NULL,
    created_at TEXT NOT NULL
  );

  -- Equipment a doctor recommended in a reply
  CREATE TABLE IF NOT EXISTS recommendations (
    message_id   INTEGER NOT NULL REFERENCES issue_messages(id) ON DELETE CASCADE,
    equipment_id INTEGER NOT NULL REFERENCES equipment(id) ON DELETE CASCADE,
    PRIMARY KEY (message_id, equipment_id)
  );

  -- Feedback about the website from anyone, signed in or not. The admin reads it.
  -- status: New -> Dealt with
  CREATE TABLE IF NOT EXISTS feedback (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER REFERENCES users(id) ON DELETE SET NULL,  -- empty if not signed in
    name       TEXT NOT NULL,
    contact    TEXT NOT NULL DEFAULT '',
    topic      TEXT NOT NULL,
    page       TEXT NOT NULL DEFAULT '',
    message    TEXT NOT NULL,
    status     TEXT NOT NULL DEFAULT 'New',
    created_at TEXT NOT NULL
  );
`;

// [name, category, description, units owned, units in repair, repair notes]
const EQUIPMENT = [
  ['Standard wheelchair', 'Mobility aids', 'Folding steel frame, 46 cm seat, swing-away footrests.', 4, 0, ''],
  ['Transit wheelchair', 'Mobility aids', 'Lightweight frame pushed by a helper, with attendant brakes.', 3, 0, ''],
  ['Bariatric wheelchair', 'Mobility aids', 'Reinforced frame, 61 cm seat, takes up to 220 kg.', 1, 1, 'Brake cable replaced, waiting for a safety check.'],
  ['Four-wheel rollator', 'Mobility aids', 'Walker with seat, basket and lockable brakes.', 4, 0, ''],
  ['Walking frame', 'Mobility aids', 'Height-adjustable frame without wheels.', 5, 0, ''],
  ['Elbow crutches (pair)', 'Mobility aids', 'Adjustable aluminium crutches with soft grips.', 6, 0, ''],
  ['Quad walking stick', 'Mobility aids', 'Four-foot base that stands on its own.', 4, 0, ''],
  ['Portable oxygen concentrator', 'Respiratory', 'Pulse flow, settings 1 to 5, two batteries.', 2, 0, ''],
  ['Home oxygen concentrator', 'Respiratory', 'Continuous flow up to 5 litres a minute.', 3, 0, ''],
  ['Compressor nebuliser', 'Respiratory', 'Tabletop nebuliser with adult and child masks.', 5, 0, ''],
  ['CPAP machine', 'Respiratory', 'Auto-adjusting, with heated humidifier.', 2, 0, ''],
  ['Suction machine', 'Respiratory', 'Portable airway suction with rechargeable battery.', 2, 0, ''],
  ['Pulse oximeter', 'Patient monitoring', 'Fingertip oxygen level and pulse monitor.', 8, 0, ''],
  ['Blood pressure monitor', 'Patient monitoring', 'Upper-arm monitor with two cuff sizes.', 6, 0, ''],
  ['Blood glucose meter', 'Patient monitoring', 'Meter with lancing device; test strips not included.', 5, 0, ''],
  ['Portable ECG monitor', 'Patient monitoring', 'Six-lead handheld ECG with printout.', 1, 0, ''],
  ['Mobile patient hoist', 'Patient handling', 'Electric hoist with medium sling, up to 180 kg.', 2, 0, ''],
  ['Standing hoist', 'Patient handling', 'Helps a patient stand with support under the arms.', 1, 0, ''],
  ['Transfer board', 'Patient handling', 'Smooth board for moving between bed and chair.', 4, 0, ''],
  ['Slide sheet set', 'Patient handling', 'Two low-friction sheets for turning in bed.', 6, 0, ''],
  ['Electric hospital bed', 'Beds and mattresses', 'Three-function profiling bed with side rails.', 3, 0, ''],
  ['Pressure relief mattress', 'Beds and mattresses', 'Alternating air mattress with pump.', 4, 0, ''],
  ['Overbed table', 'Beds and mattresses', 'Height-adjustable table on wheels.', 5, 0, ''],
  ['Bed rails (pair)', 'Beds and mattresses', 'Fold-down rails that fit most home beds.', 4, 0, ''],
  ['Shower chair', 'Rehabilitation', 'Height-adjustable chair with back rest.', 5, 0, ''],
  ['Raised toilet seat', 'Rehabilitation', 'Adds 10 cm height, with side handles.', 6, 0, ''],
  ['Commode chair', 'Rehabilitation', 'Bedside toilet chair with removable pot.', 4, 0, ''],
  ['Knee CPM machine', 'Rehabilitation', 'Moves the knee gently after surgery.', 1, 0, ''],
  ['Pedal exerciser', 'Rehabilitation', 'Seated arm and leg exerciser with adjustable resistance.', 3, 0, '']
];

// First run only: the admin, one doctor, and the equipment the clinic owns.
// There are no patients, issues or loans until real people create them.
function addStarterData(db) {
  const today = new Date().toISOString().slice(0, 10);
  const addUser = db.prepare(`INSERT INTO users (full_name, username, password_hash, gender, phone, role, specialty, created_at)
                              VALUES (?, ?, ?, ?, ?, ?, ?, ?)`);
  addUser.run(process.env.ADMIN_NAME || 'Nadia Farouk', process.env.ADMIN_USERNAME || 'admin',
    hashPassword(process.env.ADMIN_PASSWORD || 'MedLend2026!'), 'Female', '01001234567', 'admin', '', today);
  addUser.run('Dr. Karim Mansour', 'dr.karim', hashPassword(process.env.DOCTOR_PASSWORD || 'Doctor2026!'),
    'Male', '01112223344', 'doctor', 'Orthopaedics', today);

  const insert = db.prepare(`INSERT INTO equipment (name, category, description, quantity, in_repair, repair_notes, date_added)
                             VALUES (?, ?, ?, ?, ?, ?, ?)`);
  for (const item of EQUIPMENT) insert.run(...item, today);
}

// Photos dropped into the photos/ folder are added to items that have no photo yet.
// The file name is the item name in lower case with dashes, e.g. "Elbow crutches (pair)" -> elbow-crutches-pair.jpg
const PHOTO_FOLDER = path.join(__dirname, '..', 'photos');
const PHOTO_MIME = { '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.png': 'image/png', '.webp': 'image/webp' };

function photoFileName(name) {
  return name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
}

function importPhotos(db, folder = PHOTO_FOLDER) {
  if (!fs.existsSync(folder)) return;
  const files = fs.readdirSync(folder);
  const items = db.prepare('SELECT id, name FROM equipment WHERE photo_version = 0').all();
  let added = 0;
  for (const item of items) {
    const file = files.find((f) => path.parse(f).name.toLowerCase() === photoFileName(item.name) && PHOTO_MIME[path.extname(f).toLowerCase()]);
    if (!file) continue;
    const data = fs.readFileSync(path.join(folder, file));
    if (data.length > 2 * 1024 * 1024) {
      console.log(`Skipped ${file}: photos must be 2 MB or smaller.`);
      continue;
    }
    db.prepare('INSERT OR REPLACE INTO photos (equipment_id, mime, data) VALUES (?, ?, ?)').run(item.id, PHOTO_MIME[path.extname(file).toLowerCase()], data);
    db.prepare('UPDATE equipment SET photo_version = ? WHERE id = ?').run(Date.now(), item.id);
    added++;
  }
  if (added) console.log(`Added ${added} equipment photo${added === 1 ? '' : 's'} from the photos folder.`);
}

// Adds the how_to_use column to older databases, and fills in the standard steps
// for any item that has none yet (an admin's own text is never replaced).
function addHowToUse(db) {
  const columns = db.prepare('PRAGMA table_info(equipment)').all().map((c) => c.name);
  if (!columns.includes('how_to_use')) db.exec("ALTER TABLE equipment ADD COLUMN how_to_use TEXT NOT NULL DEFAULT ''");
  const update = db.prepare("UPDATE equipment SET how_to_use = ? WHERE name = ? AND how_to_use = ''");
  for (const [name, steps] of Object.entries(HOW_TO_USE)) update.run(steps.join('\n'), name);
}

function openDatabase(file = DB_FILE) {
  if (file !== ':memory:') fs.mkdirSync(path.dirname(file), { recursive: true });
  let db = new DatabaseSync(file);

  // Version 3 changed the tables a lot. An older database is set aside and a fresh one is made.
  const version = db.prepare('PRAGMA user_version').get().user_version;
  const hasTables = db.prepare("SELECT COUNT(*) AS n FROM sqlite_master WHERE type = 'table' AND name = 'users'").get().n > 0;
  if (hasTables && version < SCHEMA_VERSION && file !== ':memory:') {
    db.close();
    fs.renameSync(file, `${file}.old`);
    console.log(`Older database moved to ${file}.old; a new one is being created.`);
    db = new DatabaseSync(file);
  }

  db.exec('PRAGMA foreign_keys = ON;');
  db.exec(tables);
  db.exec(`PRAGMA user_version = ${SCHEMA_VERSION}`);

  const admins = db.prepare("SELECT COUNT(*) AS n FROM users WHERE role = 'admin'").get();
  if (admins.n === 0) {
    addStarterData(db);
    console.log('New database created at', file);
  }
  addHowToUse(db);
  if (file !== ':memory:') importPhotos(db);
  return db;
}

module.exports = { openDatabase, importPhotos, photoFileName, EQUIPMENT, hashPassword, checkPassword, DB_FILE };
