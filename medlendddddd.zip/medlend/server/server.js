// Med Lend web server: serves the pages in /public and the JSON API in api.js.
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { openDatabase } = require('./db');
const createApi = require('./api');

const PUBLIC = path.join(__dirname, '..', 'public');

// Which page file each address shows, and who may see it
// Pages shared by several roles have one file per role, because each role has its own menu.
const PAGES = {
  '/': { file: 'login.html', who: 'public' },
  '/register': { file: 'register.html', who: 'public' },
  '/accessibility': { file: 'accessibility.html', who: 'open' },   // anyone, signed in or not
  '/feedback': { file: { admin: 'feedback-admin.html', other: 'feedback.html' }, who: 'open' },  // the admin reads it, everyone else writes it
  '/dashboard': { file: 'dashboard.html', who: 'admin' },
  '/equipment': { file: 'equipment.html', who: 'admin' },
  '/patients': { file: 'patients.html', who: 'admin' },
  '/doctors': { file: 'doctors.html', who: 'admin' },
  '/loans': { file: 'loans.html', who: 'admin' },
  '/borrow': { file: 'borrow.html', who: 'user' },
  '/my-loans': { file: 'my-loans.html', who: 'user' },
  '/issues': { file: { admin: 'issues-admin.html', doctor: 'issues-doctor.html', user: 'issues-user.html' }, who: 'any' },
  '/issue': { file: { admin: 'issue-admin.html', doctor: 'issue-doctor.html', user: 'issue-user.html' }, who: 'any' },
  '/account': { file: { admin: 'account-admin.html', doctor: 'account-doctor.html', user: 'account-user.html' }, who: 'any' }
};
const HOME = { admin: '/dashboard', doctor: '/issues', user: '/borrow' };
const MAX_BODY = 4 * 1024 * 1024; // room for one equipment photo (2 MB) sent as text

const TYPES = { '.html': 'text/html', '.css': 'text/css', '.js': 'text/javascript', '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg' };

// Blocks inline scripts and styles, and stops other sites framing the app
const HEADERS = {
  'Content-Security-Policy': "default-src 'self'; style-src 'self' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; frame-ancestors 'none'",
  'X-Content-Type-Options': 'nosniff'
};

function createServer(dbFile) {
  const db = openDatabase(dbFile);
  const api = createApi(db);

  function getToken(req) {
    const match = /(?:^|;\s*)session=([a-f0-9]+)/.exec(req.headers.cookie || '');
    return match ? match[1] : null;
  }

  function sendJson(res, status, data, cookie) {
    const headers = { ...HEADERS, 'Content-Type': 'application/json', 'Cache-Control': 'no-store' };
    if (cookie) headers['Set-Cookie'] = cookie;
    res.writeHead(status, headers);
    res.end(JSON.stringify(data));
  }

  const NOT_FOUND = path.join(PUBLIC, '404.html');

  function sendFile(res, file, status = 200) {
    fs.readFile(file, (err, content) => {
      if (err) {
        // Missing file: show the friendly "Page not found" page instead of plain text
        if (file !== NOT_FOUND) return sendFile(res, NOT_FOUND, 404);
        res.writeHead(404, { 'Content-Type': 'text/plain' });
        return res.end('Not found');
      }
      res.writeHead(status, { ...HEADERS, 'Content-Type': (TYPES[path.extname(file)] || 'text/plain') + '; charset=utf-8' });
      res.end(content);
    });
  }

  function redirect(res, to) {
    res.writeHead(302, { Location: to });
    res.end();
  }

  function readBody(req) {
    return new Promise((resolve, reject) => {
      let data = '';
      req.on('data', (chunk) => {
        data += chunk;
        if (data.length > MAX_BODY) req.destroy();
      });
      req.on('end', () => {
        try { resolve(data ? JSON.parse(data) : {}); } catch { reject(new api.HttpError(400, 'Invalid request.')); }
      });
      req.on('error', reject);
    });
  }

  // Match "/api/loans/12/return" against "/api/loans/:id/return"
  function matchPath(pattern, url) {
    const a = pattern.split('/');
    const b = url.split('/');
    if (a.length !== b.length) return null;
    const params = {};
    for (let i = 0; i < a.length; i++) {
      if (a[i].startsWith(':')) params[a[i].slice(1)] = b[i];
      else if (a[i] !== b[i]) return null;
    }
    return params;
  }

  async function handleApi(req, res, url) {
    const token = getToken(req);
    const user = api.userFromToken(token);
    let cookie = null;
    const secure = req.headers['x-forwarded-proto'] === 'https' ? '; Secure' : '';
    const setSession = (newToken) => {
      cookie = newToken
        ? `session=${newToken}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${7 * 24 * 3600}${secure}`
        : `session=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0${secure}`;
    };

    for (const [method, pattern, who, handler] of api.routes) {
      const params = matchPath(pattern, url.pathname);
      if (!params || method !== req.method) continue;

      if (who !== 'public' && !user) return sendJson(res, 401, { error: 'Please sign in again.' });
      if (who !== 'public' && who !== 'any' && user.role !== who) {
        return sendJson(res, 403, { error: 'You do not have access to this.' });
      }
      const body = req.method === 'GET' ? {} : await readBody(req);
      const data = handler({ user, token, body, params, query: url.searchParams, setSession });
      return sendJson(res, 200, data, cookie);
    }
    sendJson(res, 404, { error: 'Not found.' });
  }

  // Equipment photos uploaded by the admin, e.g. /photos/12
  function handlePhoto(res, id) {
    const photo = api.getPhoto(Number(id));
    if (!photo) return sendFile(res, path.join(PUBLIC, '404.html'), 404);
    res.writeHead(200, { ...HEADERS, 'Content-Type': photo.mime, 'Cache-Control': 'public, max-age=86400' });
    res.end(Buffer.from(photo.data));
  }

  function handlePage(req, res, url) {
    const photoMatch = /^\/photos\/(\d+)$/.exec(url.pathname);
    if (photoMatch) return handlePhoto(res, photoMatch[1]);
    const page = PAGES[url.pathname];
    if (!page) {
      // css, js and images
      const file = path.join(PUBLIC, path.normalize(url.pathname));
      if (!file.startsWith(PUBLIC) || file.endsWith('.html')) return sendFile(res, path.join(PUBLIC, '404.html'), 404);
      return sendFile(res, file);
    }

    const user = api.userFromToken(getToken(req));
    if (page.who === 'open') {
      const file = typeof page.file === 'string' ? page.file : (user && page.file[user.role]) || page.file.other;
      return sendFile(res, path.join(PUBLIC, file));
    }

    if (page.who === 'public') {
      // Already signed in? Go straight to your home page.
      return user ? redirect(res, HOME[user.role]) : sendFile(res, path.join(PUBLIC, page.file));
    }
    if (!user) return redirect(res, '/');
    if (page.who !== 'any' && user.role !== page.who) return redirect(res, HOME[user.role]);
    const file = typeof page.file === 'string' ? page.file : page.file[user.role];
    sendFile(res, path.join(PUBLIC, file));
  }

  return http.createServer(async (req, res) => {
    const url = new URL(req.url, 'http://localhost');
    try {
      if (url.pathname.startsWith('/api/')) await handleApi(req, res, url);
      else handlePage(req, res, url);
    } catch (err) {
      if (err instanceof api.HttpError && (err.status === 400 || err.status === 409)) {
        // A problem with what the user typed is a normal answer, not a server failure,
        // so it is sent as 200 with ok: false. The page shows the messages, and the
        // browser console stays free of red network errors.
        sendJson(res, 200, { ok: false, error: err.message, fields: err.fields });
      } else if (err instanceof api.HttpError) {
        sendJson(res, err.status, { ok: false, error: err.message });
      } else {
        console.error(err);
        sendJson(res, 500, { error: 'Something went wrong on the server. Please try again.' });
      }
    }
  });
}

if (require.main === module) {
  const port = process.env.PORT || 3000;
  createServer().listen(port, () => console.log(`Med Lend is running at http://localhost:${port}`));
}

module.exports = createServer;
