// All the /api routes and the rules behind them.
const crypto = require('node:crypto');
const { hashPassword, checkPassword } = require('./db');

const CATEGORIES = ['Mobility aids', 'Respiratory', 'Patient monitoring', 'Patient handling', 'Beds and mattresses', 'Rehabilitation'];
const CONDITIONS = ['Good', 'Fair', 'Needs repair', 'Damaged'];
const NEEDS_ATTENTION = ['Needs repair', 'Damaged'];
const GENDERS = ['Female', 'Male', 'Prefer not to say'];
const PURPOSES = ['Home use', 'Home care with delivery', 'After surgery', 'Short-term injury'];
const DECLINE_REASONS = ['Needed for a patient with higher priority', 'A doctor\'s note is needed', 'Return date is too far away', 'Other'];
const SPECIALTIES = ['General practice', 'Orthopaedics', 'Respiratory medicine', 'Cardiology', 'Physiotherapy', 'Elderly care'];
const URGENCY = ['Routine', 'Within a few days', 'Urgent'];
const FOR_WHOM = ['Myself', 'A family member'];
const FEEDBACK_TOPICS = ['Accessibility problem', 'Something is not working', 'Suggestion', 'Other'];
const FEEDBACK_PAGES = ['Sign in or create an account', 'Borrow equipment', 'Ask a doctor', 'My loans', 'My account',
  'Dashboard', 'Patient issues', 'Loans', 'Equipment', 'Patients', 'Doctors', 'Another page'];
const PHOTO_TYPES = ['image/jpeg', 'image/png', 'image/webp'];
const MAX_PHOTO_BYTES = 2 * 1024 * 1024;
const MAX_LOAN_DAYS = 90;
const MAX_ITEMS_PER_USER = 3; // requests and loans together
const SESSION_DAYS = 7;

// An error with an HTTP status. `fields` holds one message per form field.
class HttpError extends Error {
  constructor(status, message, fields) {
    super(message);
    this.status = status;
    this.fields = fields;
  }
}

// ---------- small helpers ----------

// Today's date as YYYY-MM-DD in the server's time zone
function today() {
  const d = new Date();
  return new Date(d - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
}

function now() {
  return new Date().toISOString();
}

function addDays(date, days) {
  const d = new Date(date + 'T00:00:00Z');
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
}

function isRealDate(value) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  return new Date(value + 'T00:00:00Z').toISOString().slice(0, 10) === value;
}

function text(value) {
  return typeof value === 'string' ? value.trim() : '';
}

function stopIfErrors(errors) {
  const count = Object.keys(errors).length;
  if (count > 0) {
    throw new HttpError(400, count === 1 ? 'There is 1 problem with the form.' : `There are ${count} problems with the form.`, errors);
  }
}

function checkPhone(phone) {
  return /^(\+20|0)1[0125]\d{8}$/.test(phone) ? null : 'Enter an Egyptian mobile number, like 01012345678.';
}

function checkNewPassword(password, confirm, errors, field = 'password', confirmField = 'confirm_password') {
  if (password.length < 8 || !/[A-Za-z]/.test(password) || !/\d/.test(password)) {
    errors[field] = 'Password must be at least 8 characters and include a letter and a number.';
  } else if (password !== confirm) {
    errors[confirmField] = 'The passwords do not match.';
  }
}

function checkUsername(db, username, errors) {
  if (!/^[A-Za-z0-9_.]{3,20}$/.test(username)) {
    errors.username = 'Username must be 3 to 20 characters: letters, numbers, dots or underscores.';
  } else if (db.prepare('SELECT id FROM users WHERE username = ?').get(username)) {
    errors.username = 'That username is already taken. Try another one.';
  }
}

// Stock for each item is worked out from its loans every time, so it is never out of date.
const EQUIPMENT_FIELDS = `
  e.id, e.name, e.category, e.description, e.how_to_use, e.quantity, e.in_repair, e.repair_notes, e.photo_version, e.date_added,
  printf('EQ-%04d', e.id) AS code,
  (SELECT COUNT(*) FROM loans WHERE equipment_id = e.id AND state = 'active') AS on_loan,
  (SELECT COUNT(*) FROM loans WHERE equipment_id = e.id AND state = 'requested') AS reserved,
  e.quantity - e.in_repair
    - (SELECT COUNT(*) FROM loans WHERE equipment_id = e.id AND state IN ('requested', 'active')) AS in_stock`;

// A loan's status label comes from its state and dates, so "Overdue" is always up to date.
const LOAN_FIELDS = `
  l.*, printf('LN-%04d', l.id) AS code, printf('EQ-%04d', l.equipment_id) AS equipment_code,
  u.full_name AS borrower_name, u.phone AS borrower_phone, e.category AS category, e.how_to_use AS how_to_use,
  CASE l.state
    WHEN 'requested' THEN 'Requested'
    WHEN 'returned'  THEN 'Returned'
    WHEN 'declined'  THEN 'Declined'
    WHEN 'cancelled' THEN 'Cancelled'
    ELSE CASE WHEN l.due_date < ? THEN 'Overdue' ELSE 'On loan' END
  END AS status,
  CAST(julianday(?) - julianday(l.due_date) AS INTEGER) AS days_overdue`;

const ISSUE_FIELDS = `
  i.*, printf('IS-%04d', i.id) AS code,
  p.full_name AS patient_account_name, p.phone AS patient_phone,
  d.full_name AS doctor_name, d.specialty AS doctor_specialty,
  (SELECT COUNT(*) FROM issue_messages WHERE issue_id = i.id) AS message_count`;

module.exports = function createApi(db) {

  // Run several database changes as one step, so they all happen or none do
  function transaction(work) {
    db.exec('BEGIN IMMEDIATE');
    try {
      const result = work();
      db.exec('COMMIT');
      return result;
    } catch (err) {
      db.exec('ROLLBACK');
      throw err;
    }
  }

  // ---------- sessions ----------

  function startSession(userId) {
    const token = crypto.randomBytes(32).toString('hex');
    const expires = Date.now() + SESSION_DAYS * 24 * 60 * 60 * 1000;
    db.prepare('INSERT INTO sessions (token, user_id, expires_at) VALUES (?, ?, ?)').run(token, userId, expires);
    return token;
  }

  function userFromToken(token) {
    if (!token) return null;
    db.prepare('DELETE FROM sessions WHERE expires_at < ?').run(Date.now());
    return db.prepare(`SELECT u.id, u.full_name, u.username, u.role, u.specialty FROM sessions s
                       JOIN users u ON u.id = s.user_id WHERE s.token = ? AND u.active = 1`).get(token) || null;
  }

  // ---------- sign up, sign in, sign out ----------

  function register({ body, setSession }) {
    const form = {
      full_name: text(body.full_name),
      gender: text(body.gender),
      phone: text(body.phone).replace(/[\s-]/g, ''),
      username: text(body.username),
      password: typeof body.password === 'string' ? body.password : '',
      confirm_password: typeof body.confirm_password === 'string' ? body.confirm_password : ''
    };
    const errors = {};
    if (form.full_name.length < 2) errors.full_name = 'Enter your full name.';
    if (!GENDERS.includes(form.gender)) errors.gender = 'Select your gender.';
    if (checkPhone(form.phone)) errors.phone = checkPhone(form.phone);
    checkUsername(db, form.username, errors);
    checkNewPassword(form.password, form.confirm_password, errors);
    stopIfErrors(errors);

    const result = db.prepare(`INSERT INTO users (full_name, username, password_hash, gender, phone, role, created_at)
                               VALUES (?, ?, ?, ?, ?, 'user', ?)`)
      .run(form.full_name, form.username, hashPassword(form.password), form.gender, form.phone, today());
    setSession(startSession(Number(result.lastInsertRowid)));
    return { role: 'user' };
  }

  function login({ body, setSession }) {
    const username = text(body.username);
    const password = typeof body.password === 'string' ? body.password : '';
    const errors = {};
    if (!username) errors.username = 'Enter your username.';
    if (!password) errors.password = 'Enter your password.';
    stopIfErrors(errors);

    const user = db.prepare('SELECT * FROM users WHERE username = ?').get(username);
    if (!user || !checkPassword(password, user.password_hash)) {
      throw new HttpError(400, 'The username or password is incorrect.');
    }
    if (!user.active) {
      throw new HttpError(400, 'This account has been suspended. Please contact the equipment desk.');
    }
    setSession(startSession(user.id));
    return { role: user.role };
  }

  function logout({ token, setSession }) {
    db.prepare('DELETE FROM sessions WHERE token = ?').run(token || '');
    setSession(null);
    return { ok: true };
  }

  function lists() {
    return {
      today: today(), categories: CATEGORIES, conditions: CONDITIONS, needsAttention: NEEDS_ATTENTION,
      genders: GENDERS, purposes: PURPOSES, declineReasons: DECLINE_REASONS, specialties: SPECIALTIES,
      urgency: URGENCY, forWhom: FOR_WHOM, feedbackTopics: FEEDBACK_TOPICS, feedbackPages: FEEDBACK_PAGES, maxLoanDays: MAX_LOAN_DAYS, defaultDueDate: addDays(today(), 14)
    };
  }

  // ---------- my account (every role) ----------

  function getProfile({ user }) {
    return db.prepare('SELECT full_name, username, gender, phone, role, specialty, created_at FROM users WHERE id = ?').get(user.id);
  }

  function updateProfile({ user, body }) {
    const form = { full_name: text(body.full_name), gender: text(body.gender), phone: text(body.phone).replace(/[\s-]/g, '') };
    const errors = {};
    if (form.full_name.length < 2) errors.full_name = 'Enter your full name.';
    if (!GENDERS.includes(form.gender)) errors.gender = 'Select your gender.';
    if (checkPhone(form.phone)) errors.phone = checkPhone(form.phone);
    stopIfErrors(errors);
    db.prepare('UPDATE users SET full_name = ?, gender = ?, phone = ? WHERE id = ?').run(form.full_name, form.gender, form.phone, user.id);
    return { message: 'Your details have been saved.' };
  }

  function changePassword({ user, token, body }) {
    const current = typeof body.current_password === 'string' ? body.current_password : '';
    const next = typeof body.new_password === 'string' ? body.new_password : '';
    const confirm = typeof body.confirm_new_password === 'string' ? body.confirm_new_password : '';
    const errors = {};
    const stored = db.prepare('SELECT password_hash FROM users WHERE id = ?').get(user.id).password_hash;
    if (!current) errors.current_password = 'Enter your current password.';
    else if (!checkPassword(current, stored)) errors.current_password = 'Your current password is not correct.';
    checkNewPassword(next, confirm, errors, 'new_password', 'confirm_new_password');
    stopIfErrors(errors);

    db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(hashPassword(next), user.id);
    // Sign out everywhere else, but keep this browser signed in
    db.prepare('DELETE FROM sessions WHERE user_id = ? AND token != ?').run(user.id, token);
    return { message: 'Your password has been changed. Any other devices have been signed out.' };
  }

  // ---------- equipment and stock ----------

  function listEquipment({ query }) {
    const where = [];
    const values = [];
    const search = text(query.get('search'));
    if (search) {
      where.push("(e.name LIKE ? OR printf('EQ-%04d', e.id) LIKE ?)");
      values.push(`%${search}%`, `%${search}%`);
    }
    if (query.get('category')) { where.push('e.category = ?'); values.push(query.get('category')); }
    const stock = query.get('stock');
    if (stock === 'In stock') where.push('in_stock > 0');
    if (stock === 'Out of stock') where.push('in_stock <= 0');
    if (stock === 'In repair') where.push('e.in_repair > 0');

    // Only these column names can be used for sorting
    const sortColumns = { code: 'e.id', name: 'e.name', category: 'e.category', in_stock: 'in_stock', date_added: 'e.date_added' };
    const sort = sortColumns[query.get('sort')] || 'e.name';
    const order = query.get('order') === 'desc' ? 'DESC' : 'ASC';

    return db.prepare(`SELECT ${EQUIPMENT_FIELDS} FROM equipment e
                       ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY ${sort} ${order}, e.id`).all(...values);
  }

  function findEquipment(id) {
    const item = db.prepare(`SELECT ${EQUIPMENT_FIELDS} FROM equipment e WHERE e.id = ?`).get(id);
    if (!item) throw new HttpError(404, 'That equipment no longer exists.');
    return item;
  }

  // Checks the equipment form. `existing` is the item being edited, or null for a new one.
  function checkEquipment(body, existing) {
    const item = {
      name: text(body.name), category: text(body.category), description: text(body.description),
      how_to_use: text(body.how_to_use).split('\n').map((line) => line.trim()).filter(Boolean).join('\n'),
      quantity: Number(body.quantity), in_repair: Number(body.in_repair || 0), repair_notes: text(body.repair_notes)
    };
    const errors = {};
    if (item.name.length < 2) errors.name = 'Enter the equipment name.';
    if (!CATEGORIES.includes(item.category)) errors.category = 'Select a category.';
    if (item.description.length > 500) errors.description = 'Keep the description under 500 characters.';
    if (item.how_to_use.length > 1500) errors.how_to_use = 'Keep the instructions under 1,500 characters.';

    const out = existing ? existing.on_loan + existing.reserved : 0; // units with borrowers right now
    if (!Number.isInteger(item.quantity) || item.quantity < 1 || item.quantity > 99) {
      errors.quantity = 'Enter how many you own, from 1 to 99.';
    } else if (!Number.isInteger(item.in_repair) || item.in_repair < 0 || item.in_repair > item.quantity) {
      errors.in_repair = 'Units in repair must be between 0 and the number you own.';
    } else if (item.quantity - item.in_repair < out) {
      errors.quantity = `${out} of these are with borrowers or reserved, so you need at least ${out + item.in_repair} in total.`;
    }
    if (item.in_repair > 0 && item.repair_notes.length < 5) errors.repair_notes = 'Describe what needs repairing.';
    if (item.in_repair === 0) item.repair_notes = '';

    // Optional photo, sent as base64 text
    item.photo = null;
    if (body.photo && body.photo.data) {
      const bytes = Buffer.from(String(body.photo.data), 'base64');
      if (!PHOTO_TYPES.includes(body.photo.type)) errors.photo = 'The photo must be a JPG, PNG or WebP image.';
      else if (bytes.length > MAX_PHOTO_BYTES) errors.photo = 'The photo must be 2 MB or smaller.';
      else item.photo = { type: body.photo.type, bytes };
    }
    item.removePhoto = body.remove_photo === true || body.remove_photo === 'on';
    stopIfErrors(errors);
    return item;
  }

  function savePhoto(equipmentId, item) {
    if (item.photo) {
      db.prepare('INSERT OR REPLACE INTO photos (equipment_id, mime, data) VALUES (?, ?, ?)')
        .run(equipmentId, item.photo.type, item.photo.bytes);
      db.prepare('UPDATE equipment SET photo_version = ? WHERE id = ?').run(Date.now(), equipmentId);
    } else if (item.removePhoto) {
      db.prepare('DELETE FROM photos WHERE equipment_id = ?').run(equipmentId);
      db.prepare('UPDATE equipment SET photo_version = 0 WHERE id = ?').run(equipmentId);
    }
  }

  function addEquipment({ body }) {
    const item = checkEquipment(body, null);
    return transaction(() => {
      const result = db.prepare(`INSERT INTO equipment (name, category, description, how_to_use, quantity, in_repair, repair_notes, date_added)
                                 VALUES (?, ?, ?, ?, ?, ?, ?, ?)`)
        .run(item.name, item.category, item.description, item.how_to_use, item.quantity, item.in_repair, item.repair_notes, today());
      const id = Number(result.lastInsertRowid);
      savePhoto(id, item);
      return { message: `${item.name} was added as EQ-${String(id).padStart(4, '0')}.` };
    });
  }

  function updateEquipment({ body, params }) {
    const existing = findEquipment(params.id);
    const item = checkEquipment(body, existing);
    transaction(() => {
      db.prepare('UPDATE equipment SET name = ?, category = ?, description = ?, how_to_use = ?, quantity = ?, in_repair = ?, repair_notes = ? WHERE id = ?')
        .run(item.name, item.category, item.description, item.how_to_use, item.quantity, item.in_repair, item.repair_notes, existing.id);
      savePhoto(existing.id, item);
    });
    return { message: `${item.name} (${existing.code}) was updated.` };
  }

  function deleteEquipment({ params }) {
    const item = findEquipment(params.id);
    if (item.on_loan + item.reserved > 0) {
      throw new HttpError(409, `${item.name} has units with borrowers or reserved. Finish those loans first.`);
    }
    db.prepare('DELETE FROM equipment WHERE id = ?').run(item.id);
    return { message: `${item.name} (${item.code}) was deleted.` };
  }

  function getPhoto(id) {
    return db.prepare('SELECT mime, data FROM photos WHERE equipment_id = ?').get(id) || null;
  }

  // ---------- loans and requests ----------

  function listLoans({ status = '', search = '', userId = null } = {}) {
    const day = today();
    const where = [];
    const values = [day, day];
    if (status === 'Requested') where.push("l.state = 'requested'");
    if (status === 'On loan') where.push("l.state = 'active'");
    if (status === 'Overdue') { where.push("l.state = 'active' AND l.due_date < ?"); values.push(day); }
    if (status === 'Returned') where.push("l.state = 'returned'");
    if (status === 'Closed') where.push("l.state IN ('declined', 'cancelled')");
    if (userId) { where.push('l.user_id = ?'); values.push(userId); }
    if (search) {
      where.push("(l.equipment_name LIKE ? OR u.full_name LIKE ? OR printf('LN-%04d', l.id) LIKE ?)");
      values.push(`%${search}%`, `%${search}%`, `%${search}%`);
    }
    return db.prepare(`SELECT ${LOAN_FIELDS} FROM loans l
                       JOIN users u ON u.id = l.user_id LEFT JOIN equipment e ON e.id = l.equipment_id
                       ${where.length ? 'WHERE ' + where.join(' AND ') : ''}
                       ORDER BY l.loan_date DESC, l.id DESC`).all(...values);
  }

  function findLoan(id) {
    const loan = db.prepare('SELECT * FROM loans WHERE id = ?').get(id);
    if (!loan) throw new HttpError(404, 'That loan no longer exists.');
    return loan;
  }

  // Shared checks for a new request (patient) or a new loan made at the desk (admin)
  function checkLoanForm(body, startDate) {
    const form = {
      equipment_id: Number(body.equipment_id),
      due_date: text(body.due_date),
      purpose: text(body.purpose),
      delivery_address: text(body.delivery_address)
    };
    const errors = {};
    if (!Number.isInteger(form.equipment_id) || form.equipment_id < 1) errors.equipment_id = 'Select the equipment.';
    if (!isRealDate(form.due_date)) errors.due_date = 'Enter the return date.';
    else if (form.due_date <= startDate) errors.due_date = 'The return date must be after the loan date.';
    else if (form.due_date > addDays(startDate, MAX_LOAN_DAYS)) errors.due_date = `Loans can last up to ${MAX_LOAN_DAYS} days.`;
    if (!PURPOSES.includes(form.purpose)) errors.purpose = 'Select what the equipment is for.';
    if (form.purpose === 'Home care with delivery') {
      if (form.delivery_address.length < 5) errors.delivery_address = 'Enter the delivery address.';
    } else {
      form.delivery_address = '';
    }
    stopIfErrors(errors);
    return form;
  }

  // Rules every patient must meet before they can have another item
  function checkBorrower(userId) {
    const borrower = db.prepare("SELECT * FROM users WHERE id = ? AND role = 'user'").get(userId);
    if (!borrower) throw new HttpError(400, 'Select a patient.', { user_id: 'Select a patient.' });
    if (!borrower.active) throw new HttpError(409, `${borrower.full_name}'s account is suspended.`);
    const overdue = db.prepare("SELECT COUNT(*) AS n FROM loans WHERE user_id = ? AND state = 'active' AND due_date < ?").get(userId, today()).n;
    if (overdue > 0) throw new HttpError(409, 'Overdue equipment must be returned before borrowing more.');
    const open = db.prepare("SELECT COUNT(*) AS n FROM loans WHERE user_id = ? AND state IN ('requested', 'active')").get(userId).n;
    if (open >= MAX_ITEMS_PER_USER) throw new HttpError(409, `Each patient can have up to ${MAX_ITEMS_PER_USER} items at a time, including requests.`);
    return borrower;
  }

  function checkInStock(equipmentId) {
    const item = db.prepare(`SELECT ${EQUIPMENT_FIELDS} FROM equipment e WHERE e.id = ?`).get(equipmentId);
    if (!item || item.in_stock <= 0) {
      throw new HttpError(409, 'That equipment is out of stock.', { equipment_id: 'This item is out of stock. Choose another.' });
    }
    return item;
  }

  function addLoan(userId, item, form, date, state) {
    db.prepare(`INSERT INTO loans (user_id, equipment_id, equipment_name, loan_date, due_date, purpose, delivery_address, state)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)`)
      .run(userId, item.id, item.name, date, form.due_date, form.purpose, form.delivery_address, state);
  }

  // A patient asks to borrow. One unit is held for them until the desk approves or declines.
  function requestLoan({ user, body }) {
    const form = checkLoanForm(body, today());
    return transaction(() => {
      checkBorrower(user.id);
      const item = checkInStock(form.equipment_id);
      addLoan(user.id, item, form, today(), 'requested');
      return { message: `Request sent for the ${item.name}. We will let you know here when it is approved.` };
    });
  }

  function cancelRequest({ user, params }) {
    const loan = findLoan(params.id);
    if (loan.user_id !== user.id) throw new HttpError(404, 'That request no longer exists.');
    if (loan.state !== 'requested') throw new HttpError(409, 'Only requests that are waiting can be cancelled.');
    db.prepare("UPDATE loans SET state = 'cancelled' WHERE id = ?").run(loan.id);
    return { message: `Your request for the ${loan.equipment_name} was cancelled.` };
  }

  // The desk approves a request: the loan starts today.
  function approveRequest({ params }) {
    const loan = findLoan(params.id);
    if (loan.state !== 'requested') throw new HttpError(409, 'This request has already been dealt with.');
    if (loan.due_date <= today()) {
      throw new HttpError(409, 'The return date on this request has already passed. Decline it and ask the patient to request again.');
    }
    db.prepare("UPDATE loans SET state = 'active', loan_date = ? WHERE id = ?").run(today(), loan.id);
    return { message: `Request approved. ${loan.equipment_name} is now on loan.` };
  }

  function declineRequest({ body, params }) {
    const loan = findLoan(params.id);
    if (loan.state !== 'requested') throw new HttpError(409, 'This request has already been dealt with.');
    let reason = text(body.reason);
    const errors = {};
    if (!DECLINE_REASONS.includes(reason)) errors.reason = 'Select a reason.';
    if (reason === 'Other') {
      reason = text(body.other_reason);
      if (reason.length < 5) errors.other_reason = 'Write the reason for the patient.';
    }
    stopIfErrors(errors);
    db.prepare("UPDATE loans SET state = 'declined', decline_reason = ? WHERE id = ?").run(reason, loan.id);
    return { message: `Request for the ${loan.equipment_name} was declined.` };
  }

  // The desk hands equipment over in person: the loan starts straight away.
  function adminCreateLoan({ body }) {
    const loanDate = text(body.loan_date);
    if (!isRealDate(loanDate)) stopIfErrors({ loan_date: 'Enter the loan date.' });
    if (loanDate > today()) stopIfErrors({ loan_date: 'The loan date cannot be in the future.' });
    const form = checkLoanForm(body, loanDate);
    return transaction(() => {
      const borrower = checkBorrower(Number(body.user_id));
      const item = checkInStock(form.equipment_id);
      addLoan(borrower.id, item, form, loanDate, 'active');
      return { message: `Loan recorded: ${item.name} to ${borrower.full_name}.` };
    });
  }

  // A returned unit goes back into stock, unless it is damaged or needs repair.
  function recordReturn({ body, params }) {
    const loan = findLoan(params.id);
    if (loan.state !== 'active') throw new HttpError(409, 'Only items that are on loan can be returned.');

    const returnDate = text(body.return_date);
    const condition = text(body.return_condition);
    const notes = text(body.return_notes);
    const errors = {};
    if (!isRealDate(returnDate)) errors.return_date = 'Enter the return date.';
    else if (returnDate > today()) errors.return_date = 'The return date cannot be in the future.';
    else if (returnDate < loan.loan_date) errors.return_date = 'The return date cannot be before the loan date.';
    if (!CONDITIONS.includes(condition)) errors.return_condition = 'Select the condition it came back in.';
    const broken = NEEDS_ATTENTION.includes(condition);
    if (broken && notes.length < 5) errors.return_notes = 'Describe what is wrong with it.';
    stopIfErrors(errors);

    transaction(() => {
      db.prepare("UPDATE loans SET state = 'returned', return_date = ?, return_condition = ?, return_notes = ? WHERE id = ?")
        .run(returnDate, condition, broken ? notes : '', loan.id);
      if (broken) {
        db.prepare(`UPDATE equipment SET in_repair = in_repair + 1,
                      repair_notes = trim(repair_notes || ' ' || ?) WHERE id = ?`)
          .run(`${condition}: ${notes}`, loan.equipment_id);
      }
    });
    return {
      message: broken
        ? `Return recorded. This ${loan.equipment_name} has been moved to repair.`
        : `Return recorded. The ${loan.equipment_name} is back in stock.`
    };
  }

  // ---------- patients and doctors (user accounts) ----------

  function listPatients({ query }) {
    const search = text(query.get('search'));
    return db.prepare(`
      SELECT u.id, printf('PT-%04d', u.id) AS code, u.full_name, u.username, u.gender, u.phone, u.created_at, u.active,
        (SELECT COUNT(*) FROM loans WHERE user_id = u.id AND state IN ('requested', 'active')) AS open_items,
        (SELECT COUNT(*) FROM loans WHERE user_id = u.id AND state IN ('active', 'returned')) AS total_loans,
        (SELECT COUNT(*) FROM loans WHERE user_id = u.id AND state = 'active' AND due_date < ?) AS overdue,
        (SELECT COUNT(*) FROM issues WHERE user_id = u.id) AS issues
      FROM users u
      WHERE u.role = 'user' AND (? = '' OR u.full_name LIKE ? OR u.username LIKE ? OR u.phone LIKE ?)
      ORDER BY u.full_name`).all(today(), search, `%${search}%`, `%${search}%`, `%${search}%`);
  }

  function listDoctors() {
    return db.prepare(`
      SELECT u.id, printf('DR-%04d', u.id) AS code, u.full_name, u.username, u.gender, u.phone, u.specialty, u.created_at, u.active,
        (SELECT COUNT(*) FROM issues WHERE doctor_id = u.id AND status IN ('With doctor', 'Answered')) AS open_issues,
        (SELECT COUNT(*) FROM issues WHERE doctor_id = u.id) AS total_issues
      FROM users u WHERE u.role = 'doctor' ORDER BY u.full_name`).all();
  }

  function addDoctor({ body }) {
    const form = {
      full_name: text(body.full_name), gender: text(body.gender), phone: text(body.phone).replace(/[\s-]/g, ''),
      specialty: text(body.specialty), username: text(body.username),
      password: typeof body.password === 'string' ? body.password : ''
    };
    const errors = {};
    if (form.full_name.length < 2) errors.full_name = 'Enter the doctor\'s full name.';
    if (!GENDERS.includes(form.gender)) errors.gender = 'Select a gender.';
    if (checkPhone(form.phone)) errors.phone = checkPhone(form.phone);
    if (!SPECIALTIES.includes(form.specialty)) errors.specialty = 'Select a specialty.';
    checkUsername(db, form.username, errors);
    checkNewPassword(form.password, form.password, errors);
    stopIfErrors(errors);

    db.prepare(`INSERT INTO users (full_name, username, password_hash, gender, phone, role, specialty, created_at)
                VALUES (?, ?, ?, ?, ?, 'doctor', ?, ?)`)
      .run(form.full_name, form.username, hashPassword(form.password), form.gender, form.phone, form.specialty, today());
    return { message: `${form.full_name} was added. They can now sign in as "${form.username}".` };
  }

  // Suspend or reactivate a patient or doctor account
  function setAccountActive({ params, body }) {
    const account = db.prepare("SELECT * FROM users WHERE id = ? AND role IN ('user', 'doctor')").get(params.id);
    if (!account) throw new HttpError(404, 'That account no longer exists.');
    const active = body.active === true;
    db.prepare('UPDATE users SET active = ? WHERE id = ?').run(active ? 1 : 0, account.id);
    if (!active) db.prepare('DELETE FROM sessions WHERE user_id = ?').run(account.id);
    return {
      message: active
        ? `${account.full_name}'s account is active again.`
        : `${account.full_name}'s account is suspended. They have been signed out.`
    };
  }

  // ---------- patient issues ----------

  function listIssues({ user, query }) {
    const where = [];
    const values = [];
    if (user.role === 'user') { where.push('i.user_id = ?'); values.push(user.id); }
    if (user.role === 'doctor') { where.push('i.doctor_id = ?'); values.push(user.id); }
    const status = query.get('status');
    if (status === 'Open') where.push("i.status != 'Closed'");
    else if (status) { where.push('i.status = ?'); values.push(status); }
    return db.prepare(`SELECT ${ISSUE_FIELDS} FROM issues i
                       JOIN users p ON p.id = i.user_id LEFT JOIN users d ON d.id = i.doctor_id
                       ${where.length ? 'WHERE ' + where.join(' AND ') : ''}
                       ORDER BY CASE i.urgency WHEN 'Urgent' THEN 0 WHEN 'Within a few days' THEN 1 ELSE 2 END,
                                i.updated_at DESC`).all(...values);
  }

  // Each role may only open the issues that belong to them
  function findIssue(id, user) {
    const issue = db.prepare(`SELECT ${ISSUE_FIELDS} FROM issues i
                              JOIN users p ON p.id = i.user_id LEFT JOIN users d ON d.id = i.doctor_id
                              WHERE i.id = ?`).get(id);
    const allowed = issue && (user.role === 'admin' || (user.role === 'user' && issue.user_id === user.id)
      || (user.role === 'doctor' && issue.doctor_id === user.id));
    if (!allowed) throw new HttpError(404, 'That issue does not exist or is not yours to view.');
    return issue;
  }

  function createIssue({ user, body }) {
    const form = {
      subject: text(body.subject), details: text(body.details), for_whom: text(body.for_whom),
      patient_name: text(body.patient_name), urgency: text(body.urgency)
    };
    const errors = {};
    if (form.subject.length < 5 || form.subject.length > 120) errors.subject = 'Write a short title, 5 to 120 characters.';
    if (form.details.length < 20) errors.details = 'Describe the condition in at least 20 characters so the doctor can help.';
    else if (form.details.length > 2000) errors.details = 'Keep the description under 2,000 characters.';
    if (!FOR_WHOM.includes(form.for_whom)) errors.for_whom = 'Select who the equipment is for.';
    if (form.for_whom === 'A family member') {
      if (form.patient_name.length < 2) errors.patient_name = 'Enter the patient\'s name.';
    } else {
      form.patient_name = '';
    }
    if (!URGENCY.includes(form.urgency)) errors.urgency = 'Select how soon you need help.';
    stopIfErrors(errors);

    const result = db.prepare(`INSERT INTO issues (user_id, subject, details, for_whom, patient_name, urgency, created_at, updated_at)
                               VALUES (?, ?, ?, ?, ?, ?, ?, ?)`)
      .run(user.id, form.subject, form.details, form.for_whom, form.patient_name, form.urgency, now(), now());
    return { id: Number(result.lastInsertRowid), message: 'Your issue was sent. The equipment desk will pass it to a doctor.' };
  }

  function getIssue({ user, params }) {
    const issue = findIssue(params.id, user);
    const messages = db.prepare(`SELECT m.id, m.body, m.created_at, u.full_name AS author, u.role AS author_role, u.specialty
                                 FROM issue_messages m JOIN users u ON u.id = m.author_id
                                 WHERE m.issue_id = ? ORDER BY m.id`).all(issue.id);
    const recommend = db.prepare(`SELECT ${EQUIPMENT_FIELDS} FROM recommendations r JOIN equipment e ON e.id = r.equipment_id
                                  WHERE r.message_id = ? ORDER BY e.name`);
    for (const m of messages) m.recommended = recommend.all(m.id);
    return { ...issue, messages };
  }

  // Patient follow-up, or a doctor's answer (which can recommend equipment)
  function replyToIssue({ user, params, body }) {
    const issue = findIssue(params.id, user);
    if (user.role === 'admin') throw new HttpError(403, 'Only the patient and their doctor can reply.');
    if (issue.status === 'Closed') throw new HttpError(409, 'This issue is closed.');
    const message = text(body.message);
    const errors = {};
    if (message.length < 2) errors.message = 'Write your message.';
    else if (message.length > 2000) errors.message = 'Keep the message under 2,000 characters.';

    let equipmentIds = [];
    if (user.role === 'doctor') {
      equipmentIds = [].concat(body.equipment_ids || []).map(Number).filter((n) => Number.isInteger(n) && n > 0);
      const known = db.prepare('SELECT id FROM equipment WHERE id = ?');
      if (equipmentIds.some((id) => !known.get(id))) errors.equipment_ids = 'One of the chosen items no longer exists.';
    }
    stopIfErrors(errors);

    transaction(() => {
      const result = db.prepare('INSERT INTO issue_messages (issue_id, author_id, body, created_at) VALUES (?, ?, ?, ?)')
        .run(issue.id, user.id, message, now());
      const messageId = Number(result.lastInsertRowid);
      const addRec = db.prepare('INSERT OR IGNORE INTO recommendations (message_id, equipment_id) VALUES (?, ?)');
      for (const id of equipmentIds) addRec.run(messageId, id);
      const newStatus = user.role === 'doctor' ? 'Answered' : (issue.doctor_id ? 'With doctor' : 'New');
      db.prepare('UPDATE issues SET status = ?, updated_at = ? WHERE id = ?').run(newStatus, now(), issue.id);
    });
    return {
      message: user.role === 'doctor'
        ? `Your answer was sent to the patient${equipmentIds.length ? ` with ${equipmentIds.length} recommended item${equipmentIds.length === 1 ? '' : 's'}` : ''}.`
        : 'Your message was sent.'
    };
  }

  function assignDoctor({ params, body, user }) {
    const issue = findIssue(params.id, user);
    if (issue.status === 'Closed') throw new HttpError(409, 'This issue is closed.');
    const doctor = db.prepare("SELECT * FROM users WHERE id = ? AND role = 'doctor' AND active = 1").get(Number(body.doctor_id));
    if (!doctor) stopIfErrors({ doctor_id: 'Select a doctor.' });
    const status = issue.status === 'Answered' ? 'Answered' : 'With doctor';
    db.prepare('UPDATE issues SET doctor_id = ?, status = ?, updated_at = ? WHERE id = ?').run(doctor.id, status, now(), issue.id);
    return { message: `${issue.code} was assigned to ${doctor.full_name}.` };
  }

  function closeIssue({ params, user }) {
    const issue = findIssue(params.id, user);
    if (user.role === 'doctor') throw new HttpError(403, 'Only the patient or the equipment desk can close an issue.');
    db.prepare("UPDATE issues SET status = 'Closed', updated_at = ? WHERE id = ?").run(now(), issue.id);
    return { message: `${issue.code} is closed.` };
  }

  // ---------- feedback about the website ----------

  // Anyone can send feedback. If they are signed in, their account name is used.
  function sendFeedback({ user, body }) {
    const form = {
      name: user ? user.full_name : text(body.name),
      contact: text(body.contact),
      topic: text(body.topic),
      page: text(body.page),
      message: text(body.message)
    };
    const errors = {};
    if (!user && form.name.length < 2) errors.name = 'Enter your name.';
    if (form.contact.length > 100) errors.contact = 'Keep the email or phone number under 100 characters.';
    if (!FEEDBACK_TOPICS.includes(form.topic)) errors.topic = 'Select what your feedback is about.';
    if (form.page && !FEEDBACK_PAGES.includes(form.page)) form.page = '';
    if (form.message.length < 10) errors.message = 'Write your feedback in at least 10 characters.';
    else if (form.message.length > 2000) errors.message = 'Keep your feedback under 2,000 characters.';
    stopIfErrors(errors);

    db.prepare(`INSERT INTO feedback (user_id, name, contact, topic, page, message, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)`)
      .run(user ? user.id : null, form.name, form.contact, form.topic, form.page, form.message, now());
    return { message: 'Thank you. Your feedback was sent to the equipment desk.' };
  }

  function listFeedback({ query }) {
    const status = query.get('status') || '';
    const rows = db.prepare(`SELECT f.*, printf('FB-%04d', f.id) AS code, u.role AS role, u.username AS username
                             FROM feedback f LEFT JOIN users u ON u.id = f.user_id
                             ORDER BY f.status = 'New' DESC, f.created_at DESC`).all();
    return status ? rows.filter((f) => f.status === status) : rows;
  }

  function setFeedbackStatus({ params, body }) {
    const item = db.prepare("SELECT *, printf('FB-%04d', id) AS code FROM feedback WHERE id = ?").get(Number(params.id));
    if (!item) throw new HttpError(404, 'That feedback no longer exists.');
    const status = body.status === 'Dealt with' ? 'Dealt with' : 'New';
    db.prepare('UPDATE feedback SET status = ? WHERE id = ?').run(status, item.id);
    return { message: status === 'Dealt with' ? `${item.code} is marked as dealt with.` : `${item.code} is marked as new again.` };
  }

  // ---------- dashboard ----------

  function dashboard() {
    const items = db.prepare(`SELECT ${EQUIPMENT_FIELDS} FROM equipment e ORDER BY e.name`).all();
    const sum = (key) => items.reduce((total, i) => total + Math.max(0, i[key]), 0);
    const overdueLoans = listLoans({ status: 'Overdue' });
    const requests = listLoans({ status: 'Requested' });
    const count = (sql, ...v) => db.prepare(sql).get(...v).n;

    // Loans started in each of the last 8 weeks (7-day blocks, the last one ending today)
    const weeks = [];
    for (let i = 7; i >= 0; i--) {
      const end = addDays(today(), -i * 7);
      const start = addDays(end, -6);
      weeks.push({ start, end, loans: count("SELECT COUNT(*) AS n FROM loans WHERE state IN ('active', 'returned') AND loan_date BETWEEN ? AND ?", start, end) });
    }

    return {
      today: today(),
      counts: {
        items: items.length,
        units: sum('quantity'),
        in_stock: sum('in_stock'),
        on_loan: sum('on_loan'),
        requests: requests.length,
        overdue: overdueLoans.length,
        new_issues: count("SELECT COUNT(*) AS n FROM issues WHERE status = 'New'"),
        patients: count("SELECT COUNT(*) AS n FROM users WHERE role = 'user'"),
        new_feedback: count("SELECT COUNT(*) AS n FROM feedback WHERE status = 'New'")
      },
      requests,
      newIssues: db.prepare(`SELECT ${ISSUE_FIELDS} FROM issues i JOIN users p ON p.id = i.user_id LEFT JOIN users d ON d.id = i.doctor_id
                             WHERE i.status = 'New' ORDER BY i.created_at`).all(),
      overdueLoans,
      recentLoans: listLoans().filter((l) => l.state === 'active' || l.state === 'returned').slice(0, 5),
      weeks,
      needsAttention: items.filter((i) => i.in_stock <= 0 || i.in_repair > 0)
    };
  }

  // ---------- route table ----------
  // who: 'public' = anyone, 'any' = signed in, 'staff' = admin or doctor, or one role only

  const routes = [
    ['POST', '/api/register', 'public', register],
    ['POST', '/api/login', 'public', login],
    ['POST', '/api/logout', 'public', logout],
    ['GET', '/api/me', 'any', ({ user }) => user],
    ['GET', '/api/session', 'public', ({ user }) => ({ user })],  // like /api/me, but no 401 when signed out
    ['GET', '/api/lists', 'public', lists],

    ['GET', '/api/profile', 'any', getProfile],
    ['PUT', '/api/profile', 'any', updateProfile],
    ['PUT', '/api/profile/password', 'any', changePassword],

    ['GET', '/api/equipment', 'any', listEquipment],
    ['GET', '/api/equipment/:id', 'any', ({ params }) => findEquipment(params.id)],
    ['POST', '/api/equipment', 'admin', addEquipment],
    ['PUT', '/api/equipment/:id', 'admin', updateEquipment],
    ['DELETE', '/api/equipment/:id', 'admin', deleteEquipment],

    ['GET', '/api/my-loans', 'user', ({ user }) => listLoans({ userId: user.id })],
    ['POST', '/api/my-loans', 'user', requestLoan],
    ['POST', '/api/my-loans/:id/cancel', 'user', cancelRequest],

    ['GET', '/api/issues', 'any', listIssues],
    ['POST', '/api/issues', 'user', createIssue],
    ['GET', '/api/issues/:id', 'any', getIssue],
    ['POST', '/api/issues/:id/messages', 'any', replyToIssue],
    ['POST', '/api/issues/:id/assign', 'admin', assignDoctor],
    ['POST', '/api/issues/:id/close', 'any', closeIssue],

    ['POST', '/api/feedback', 'public', sendFeedback],
    ['GET', '/api/feedback', 'admin', listFeedback],
    ['PUT', '/api/feedback/:id/status', 'admin', setFeedbackStatus],

    ['GET', '/api/dashboard', 'admin', dashboard],
    ['GET', '/api/patients', 'admin', listPatients],
    ['GET', '/api/patients/:id/loans', 'admin', ({ params }) => listLoans({ userId: Number(params.id) })],
    ['GET', '/api/doctors', 'admin', listDoctors],
    ['POST', '/api/doctors', 'admin', addDoctor],
    ['PUT', '/api/accounts/:id/status', 'admin', setAccountActive],
    ['GET', '/api/loans', 'admin', ({ query }) => listLoans({ status: query.get('status') || '', search: text(query.get('search')) })],
    ['POST', '/api/loans', 'admin', adminCreateLoan],
    ['POST', '/api/loans/:id/approve', 'admin', approveRequest],
    ['POST', '/api/loans/:id/decline', 'admin', declineRequest],
    ['POST', '/api/loans/:id/return', 'admin', recordReturn]
  ];

  return { routes, userFromToken, getPhoto, HttpError };
};
