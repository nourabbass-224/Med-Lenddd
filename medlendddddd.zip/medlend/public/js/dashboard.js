// Admin dashboard: stock, requests, new patient issues, a weekly loans chart, overdue loans and items to look at.
import { api, esc, formatDate, badge, showMessage, setupPage, stockBadge } from './main.js';

setupPage();

function loanTable(loans, label, dateColumn) {
  return `<div class="table-wrap" role="region" aria-label="${label}" tabindex="0">
    <table>
      <thead><tr><th scope="col">Loan</th><th scope="col">Equipment</th><th scope="col">Patient</th><th scope="col">${dateColumn}</th><th scope="col">Status</th></tr></thead>
      <tbody>
        ${loans.map((l) => `<tr>
          <td class="code">${l.code}</td>
          <td>${esc(l.equipment_name)}</td>
          <td>${esc(l.borrower_name)}<span class="sub">${esc(l.borrower_phone)}</span></td>
          <td>${dateColumn === 'Requested on' ? formatDate(l.loan_date) : formatDate(l.due_date)}${l.status === 'Overdue'
            ? `<span class="sub">${l.days_overdue} day${l.days_overdue === 1 ? '' : 's'} late</span>` : ''}</td>
          <td>${badge(l.status)}</td>
        </tr>`).join('')}
      </tbody>
    </table>
  </div>`;
}

function issueTable(issues) {
  return `<div class="table-wrap" role="region" aria-label="New issues" tabindex="0">
    <table>
      <thead><tr><th scope="col">Issue</th><th scope="col">Patient</th><th scope="col">How soon</th><th scope="col">Sent</th><th scope="col">Actions</th></tr></thead>
      <tbody>
        ${issues.map((i) => `<tr>
          <th scope="row">${esc(i.subject)}<span class="sub">${i.code}</span></th>
          <td>${esc(i.patient_account_name)}${i.patient_name ? `<span class="sub">for ${esc(i.patient_name)}</span>` : ''}</td>
          <td>${i.urgency === 'Urgent' ? badge('Urgent') : esc(i.urgency)}</td>
          <td>${formatDate(i.created_at.slice(0, 10))}</td>
          <td><a class="btn btn-primary btn-small" href="/issue?id=${i.id}">Assign a doctor<span class="visually-hidden"> for ${esc(i.subject)}</span></a></td>
        </tr>`).join('')}
      </tbody>
    </table>
  </div>`;
}

// Bar chart drawn as SVG. Screen readers get the same numbers from a table instead,
// so the drawing itself is hidden from them.
function weeklyChart(weeks) {
  const total = weeks.reduce((sum, w) => sum + w.loans, 0);
  const highest = Math.max(4, ...weeks.map((w) => w.loans));
  const barWidth = 34;
  const gap = 14;
  const chartHeight = 140;
  const label = (w) => formatDate(w.start).replace(/ \d{4}$/, '');

  const bars = weeks.map((w, i) => {
    const x = 30 + i * (barWidth + gap);
    const h = Math.round((w.loans / highest) * chartHeight);
    const y = 10 + chartHeight - h;
    return `<rect x="${x}" y="${y}" width="${barWidth}" height="${Math.max(h, 1)}" rx="3" class="bar"></rect>
      <text x="${x + barWidth / 2}" y="${y - 4}" text-anchor="middle" class="chart-value">${w.loans}</text>
      <text x="${x + barWidth / 2}" y="${chartHeight + 28}" text-anchor="middle" class="chart-label">${label(w)}</text>`;
  }).join('');

  return `<figure class="chart">
    <svg viewBox="0 0 ${40 + weeks.length * (barWidth + gap)} ${chartHeight + 40}" aria-hidden="true" focusable="false">
      <line x1="24" y1="${chartHeight + 10}" x2="${30 + weeks.length * (barWidth + gap)}" y2="${chartHeight + 10}" class="chart-axis"></line>
      ${bars}
    </svg>
    <figcaption>${total === 0
      ? 'No loans have started in the last 8 weeks yet.'
      : `${total} loan${total === 1 ? '' : 's'} started in the last 8 weeks. Each bar is a week, labelled by its first day.`}</figcaption>
    <table class="visually-hidden">
      <caption>Loans started per week</caption>
      <thead><tr><th scope="col">Week starting</th><th scope="col">Loans</th></tr></thead>
      <tbody>${weeks.map((w) => `<tr><td>${formatDate(w.start)}</td><td>${w.loans}</td></tr>`).join('')}</tbody>
    </table>
  </figure>`;
}

async function load() {
  try {
    const data = await api('/api/dashboard');
    document.getElementById('intro').textContent = `Equipment, loans and patient issues for ${formatDate(data.today)}.`;
    for (const key of ['in_stock', 'on_loan', 'requests', 'new_issues', 'overdue', 'patients', 'new_feedback']) {
      document.getElementById(key).textContent = data.counts[key];
    }

    document.getElementById('issues-list').innerHTML = data.newIssues.length
      ? issueTable(data.newIssues)
      : '<p class="empty">No new issues. Every patient issue has a doctor.</p>';

    document.getElementById('requests-list').innerHTML = data.requests.length
      ? loanTable(data.requests, 'Requests waiting', 'Requested on')
      : '<p class="empty">No equipment requests are waiting.</p>';

    document.getElementById('chart').innerHTML = weeklyChart(data.weeks);

    document.getElementById('overdue-list').innerHTML = data.overdueLoans.length
      ? loanTable(data.overdueLoans, 'Overdue loans', 'Due back')
      : '<p class="empty">No loans are overdue.</p>';

    document.getElementById('recent-list').innerHTML = data.recentLoans.length
      ? loanTable(data.recentLoans, 'Recent loans', 'Due back')
      : '<p class="empty">No one has borrowed anything yet. New loans will appear here.</p>';

    document.getElementById('attention-list').innerHTML = data.needsAttention.length
      ? `<ul class="simple-list">${data.needsAttention.map((item) => `<li>
          <a href="/equipment?search=${item.code}">${esc(item.name)} (${item.code})</a>
          ${stockBadge(item)}
          ${item.in_repair ? `<span class="meta">${item.in_repair} in repair: ${esc(item.repair_notes)}</span>` : ''}
        </li>`).join('')}</ul>`
      : '<p class="empty">Everything is in stock and working.</p>';
  } catch (err) {
    showMessage('The dashboard could not be loaded. ' + err.message, 'error');
  }
}

load();
