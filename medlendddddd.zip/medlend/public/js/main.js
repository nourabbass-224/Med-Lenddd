// Code shared by every page.

// Call the API. Throws an Error with .fields (one message per form field) when something is wrong.
// Form problems come back as { ok: false, error, fields }.
export async function api(url, method = 'GET', body) {
  let res;
  try {
    res = await fetch(url, {
      method,
      headers: body ? { 'Content-Type': 'application/json' } : {},
      body: body ? JSON.stringify(body) : undefined
    });
  } catch {
    throw new Error('Could not connect to the server. Check your connection and try again.');
  }
  const data = await res.json().catch(() => ({}));
  if (res.status === 401 && url !== '/api/login') {
    window.location.href = '/';
  }
  if (!res.ok || data.ok === false) {
    const error = new Error(data.error || 'Something went wrong. Please try again.');
    error.fields = data.fields || {};
    throw error;
  }
  return data;
}

// Escape text before putting it into HTML, so names like <b> show as text
export function esc(value) {
  return String(value ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

// "2026-11-11" -> "11 Nov 2026"
export function formatDate(date) {
  if (!date) return '—';
  return new Date(date + 'T00:00:00Z').toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric', timeZone: 'UTC' });
}

// Status badges have an icon and a word, so they never rely on colour alone
const BADGES = {
  Available: ['available', '✓'],
  Borrowed: ['borrowed', '↗'],
  Unavailable: ['unavailable', '✕'],
  'On loan': ['borrowed', '●'],
  Overdue: ['overdue', '!'],
  Returned: ['completed', '✓'],
  Requested: ['requested', '◷'],
  Reserved: ['requested', '◷'],
  Declined: ['completed', '✕'],
  Cancelled: ['completed', '–'],
  Active: ['available', '✓'],
  Suspended: ['unavailable', '✕'],
  'In stock': ['available', '✓'],
  'Out of stock': ['unavailable', '✕'],
  'In repair': ['unavailable', '⚠'],
  New: ['requested', '◷'],
  'With doctor': ['borrowed', '●'],
  Answered: ['available', '✓'],
  Closed: ['completed', '–'],
  Urgent: ['overdue', '!'],
  'Needs repair': ['unavailable', '⚠'],
  Damaged: ['unavailable', '⚠'],
  'Dealt with': ['completed', '✓']
};
export function badge(status) {
  const [style, icon] = BADGES[status] || ['completed', '•'];
  return `<span class="badge badge-${style}"><span aria-hidden="true">${icon}</span> ${esc(status)}</span>`;
}

// Show a success or error message at the top of the page. Screen readers announce it.
export function showMessage(text, type = 'success') {
  const box = document.getElementById(type === 'error' ? 'error-message' : 'success-message');
  document.getElementById('success-message').innerHTML = '';
  document.getElementById('error-message').innerHTML = '';
  setTimeout(() => {
    box.innerHTML = `<div class="flash flash-${type}">
      <span aria-hidden="true">${type === 'error' ? '!' : '✓'}</span>
      <p>${esc(text)}</p>
      <button type="button" class="flash-close">Dismiss<span class="visually-hidden"> message</span></button>
    </div>`;
    box.querySelector('.flash-close').addEventListener('click', () => { box.innerHTML = ''; });
  }, 100);
}

// Tell screen reader users something without showing it (e.g. "5 results")
// Inside an open pop-up, the page behind it is hidden from screen readers, so use the pop-up's own status line.
export function announce(text) {
  const box = document.querySelector('dialog[open] [data-announcer]') || document.getElementById('announcer');
  box.textContent = '';
  setTimeout(() => { box.textContent = text; }, 50);
}

// ---------- forms ----------

export function getValues(form) {
  return Object.fromEntries(new FormData(form));
}

export function clearErrors(form) {
  form.querySelector('.error-summary').hidden = true;
  form.querySelectorAll('[aria-invalid]').forEach((field) => field.removeAttribute('aria-invalid'));
  form.querySelectorAll('.field-error').forEach((p) => { p.hidden = true; p.textContent = ''; });
}

// Show an error list at the top of the form with links to each field,
// and a message next to each field. What the user typed is left in place.
export function showErrors(form, fields, fallback) {
  clearErrors(form);
  const summary = form.querySelector('.error-summary');
  const list = summary.querySelector('ul');
  list.innerHTML = '';

  for (const [name, message] of Object.entries(fields || {})) {
    const field = form.elements[name];
    const input = field instanceof RadioNodeList ? field[0] : field;
    if (!input) continue;
    const errorText = document.getElementById(input.dataset.error || input.id + '-error');
    errorText.textContent = message;
    errorText.hidden = false;
    (field instanceof RadioNodeList ? [...field] : [input]).forEach((f) => f.setAttribute('aria-invalid', 'true'));
    list.insertAdjacentHTML('beforeend', `<li><a href="#${input.id}">${esc(message)}</a></li>`);
  }
  if (!list.children.length) list.innerHTML = `<li>${esc(fallback || 'Something went wrong. Please try again.')}</li>`;

  summary.hidden = false;
  summary.focus();
}

// Quick check in the browser before sending: required fields, email/pattern, min length.
// The server checks everything again.
export function checkForm(form) {
  const errors = {};
  for (const field of form.elements) {
    if (!field.name || field.disabled || errors[field.name]) continue;
    const label = field.dataset.label || field.name;
    const value = field.type === 'radio' ? form.elements[field.name].value : field.value.trim();
    if (field.required && !value) {
      errors[field.name] = (field.tagName === 'SELECT' || field.type === 'radio' ? 'Select ' : 'Enter ') + label + '.';
    } else if (value && field.validity.patternMismatch) {
      errors[field.name] = field.dataset.patternError;
    } else if (value && field.minLength > 0 && value.length < field.minLength) {
      errors[field.name] = `${label[0].toUpperCase() + label.slice(1)} must be at least ${field.minLength} characters.`;
    }
  }
  return errors;
}

// Show or hide an extra section. Hidden fields are disabled so they are skipped.
export function showIf(section, show) {
  section.hidden = !show;
  section.querySelectorAll('input, select, textarea').forEach((f) => { f.disabled = !show; });
}

// Put a button in a "loading" state. Returns a function that puts it back.
export function busy(button, text) {
  const original = button.innerHTML;
  button.disabled = true;
  button.innerHTML = `<span class="spinner" aria-hidden="true"></span> ${esc(text)}`;
  announce(text);
  return () => { button.disabled = false; button.innerHTML = original; };
}

// ---------- dialogs ----------

// Native <dialog> keeps focus inside and closes with Escape.
// When it closes, focus goes back to the button that opened it.
export function openDialog(dialog, opener) {
  dialog.opener = opener;
  dialog.showModal();
  const first = dialog.querySelector('input:not([type=hidden]):not(:disabled), select, textarea, [data-first]');
  if (first) first.focus();
}

function setupDialogs() {
  document.querySelectorAll('dialog').forEach((dialog) => {
    dialog.querySelectorAll('[data-close]').forEach((btn) => btn.addEventListener('click', () => dialog.close()));
    dialog.addEventListener('close', () => {
      if (dialog.opener && document.contains(dialog.opener)) dialog.opener.focus();
    });
  });
}

// ---------- page layout ----------

export async function setupPage() {
  setupDialogs();

  const menuButton = document.querySelector('.menu-toggle');
  menuButton.addEventListener('click', () => {
    const open = menuButton.getAttribute('aria-expanded') !== 'true';
    menuButton.setAttribute('aria-expanded', open);
    document.querySelector('.sidebar').classList.toggle('is-open', open);
  });

  document.getElementById('logout').addEventListener('click', async () => {
    await api('/api/logout', 'POST').catch(() => {});
    window.location.href = '/?signedout';
  });

  const me = await api('/api/me');
  document.getElementById('user-name').textContent = me.full_name;
  return me;
}

// The item's uploaded photo, or else the drawing for its category
// e.g. "Mobility aids" -> /img/equipment/mobility-aids.svg
export function pictureFor(item) {
  if (item.photo_version) return `/photos/${item.id}?v=${item.photo_version}`;
  return '/img/equipment/' + String(item.category).toLowerCase().replace(/\s+/g, '-') + '.svg';
}

// "3 in stock" or "Out of stock", as a badge with an icon and words
export function stockBadge(item) {
  const n = Math.max(0, item.in_stock);
  return n > 0
    ? `<span class="badge badge-available"><span aria-hidden="true">✓</span> ${n} in stock</span>`
    : badge('Out of stock');
}

// "11 Nov 2026, 14:05" for message times
export function formatDateTime(iso) {
  return new Date(iso).toLocaleString('en-GB', { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
}

// "How to use" steps as a show/hide section. Uses the native <details> element,
// so it works with the keyboard and screen readers without extra code.
// showName: put the item name in the visible heading (used where several items are listed together)
export function howToUse(item, name = item.name, showName = false) {
  const steps = String(item.how_to_use || '').split('\n').filter(Boolean);
  if (!steps.length) return '';
  return `<details class="how-to">
    <summary>${showName ? `How to use: ${esc(name)}` : `How to use<span class="visually-hidden"> the ${esc(name)}</span>`}</summary>
    <ol>${steps.map((step) => `<li>${esc(step)}</li>`).join('')}</ol>
    <p class="how-to-note">Always follow what your doctor or therapist told you.</p>
  </details>`;
}
