// Sign-up page: checks the form in the browser, then creates the user account on the server.
import { api, getValues, checkForm, showErrors, clearErrors, busy } from './main.js';

const form = document.getElementById('register-form');

document.querySelector('.show-password').addEventListener('change', (e) => {
  const type = e.target.checked ? 'text' : 'password';
  form.elements.password.type = type;
  form.elements.confirm_password.type = type;
});

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  clearErrors(form);

  const values = getValues(form);
  const errors = checkForm(form);
  const strong = values.password.length >= 8 && /[A-Za-z]/.test(values.password) && /\d/.test(values.password);
  if (!errors.password && !strong) {
    errors.password = 'Password must be at least 8 characters and include a letter and a number.';
  }
  if (!errors.password && !errors.confirm_password && values.password !== values.confirm_password) {
    errors.confirm_password = 'The passwords do not match.';
  }
  if (Object.keys(errors).length) return showErrors(form, errors);

  const done = busy(form.querySelector('[type=submit]'), 'Creating account…');
  try {
    await api('/api/register', 'POST', values);
    window.location.href = '/borrow?welcome';
  } catch (err) {
    done();
    showErrors(form, err.fields, err.message);
  }
});
