// "Patient issues" list for every role:
//   patient – their own issues, and a form to describe a new one
//   admin   – every issue, with a button to assign a doctor
//   doctor  – the issues assigned to them
import { api, esc, formatDate, badge, showMessage, announce, getValues, checkForm, showErrors, clearErrors,
  showIf, busy, openDialog, setupPage } from './main.js';

const me = await setupPage();
const rows = document.getElementById('rows');
const filters = document.getElementById('filters'); // admin and doctor only
let issues = [];
let lists = {};

// The dashboard links here with ?status=New
const startStatus = new URLSearchParams(location.search).get('status');
if (filters && startStatus) filters.status.value = startStatus;

function row(issue) {
  const open = `<a href="/issue?id=${issue.id}" class="btn btn-secondary btn-small">Open<span class="visually-hidden"> ${esc(issue.subject)}</span></a>`;
  const assign = me.role === 'admin' && issue.status !== 'Closed'
    ? `<button type="button" class="btn btn-primary btn-small" data-assign="${issue.id}">${issue.doctor_id ? 'Change doctor' : 'Assign'}<span class="visually-hidden"> for ${esc(issue.subject)}</span></button>`
    : '';
  const patient = `${esc(issue.patient_account_name)}${issue.patient_name ? `<span class="sub">for ${esc(issue.patient_name)}</span>` : ''}`;
  const doctor = issue.doctor_name ? `${esc(issue.doctor_name)}<span class="sub">${esc(issue.doctor_specialty)}</span>` : 'Not assigned yet';
  const urgency = issue.urgency === 'Urgent' ? badge('Urgent') : esc(issue.urgency);

  const cells = [`<td class="code">${issue.code}</td>`, `<th scope="row">${esc(issue.subject)}<span class="sub">${issue.message_count} message${issue.message_count === 1 ? '' : 's'}</span></th>`];
  if (me.role === 'user') cells.push(`<td>${doctor}</td>`);
  else cells.push(`<td>${patient}</td>`, `<td>${urgency}</td>`);
  cells.push(`<td>${badge(issue.status)}</td>`);
  if (me.role === 'admin') cells.push(`<td>${doctor}</td>`);
  cells.push(`<td>${formatDate(issue.updated_at.slice(0, 10))}</td>`, `<td class="cell-actions">${open} ${assign}</td>`);
  return `<tr>${cells.join('')}</tr>`;
}

async function loadIssues() {
  const columns = document.querySelectorAll('thead th').length;
  const status = filters ? filters.status.value : '';
  try {
    issues = await api('/api/issues?status=' + encodeURIComponent(status));
  } catch (err) {
    return showMessage(err.message, 'error');
  }
  const results = document.getElementById('results');
  if (issues.length === 0) {
    const message = me.role === 'user'
      ? 'You have not asked a doctor anything yet. Use "Describe a new issue" to start.'
      : 'No issues match this filter.';
    rows.innerHTML = `<tr><td colspan="${columns}" class="empty">${message}</td></tr>`;
    results.textContent = message;
  } else {
    rows.innerHTML = issues.map(row).join('');
    results.textContent = `Showing ${issues.length} issue${issues.length === 1 ? '' : 's'}. Urgent issues are listed first.`;
  }
  announce(results.textContent);
}

if (filters) filters.addEventListener('change', loadIssues);

// ---------- admin: assign a doctor ----------

const assignDialog = document.getElementById('assign-dialog');
if (assignDialog) {
  const assignForm = document.getElementById('assign-form');
  let assigning = null;

  rows.addEventListener('click', async (e) => {
    const button = e.target.closest('button[data-assign]');
    if (!button) return;
    assigning = issues.find((i) => i.id === Number(button.dataset.assign));
    clearErrors(assignForm);
    document.getElementById('assign-info').textContent = `${assigning.code}: ${assigning.subject} (${assigning.urgency}).`;
    const doctors = (await api('/api/doctors')).filter((d) => d.active);
    assignForm.elements.doctor_id.innerHTML = '<option value="">Select a doctor</option>' +
      doctors.map((d) => `<option value="${d.id}"${d.id === assigning.doctor_id ? ' selected' : ''}>${esc(d.full_name)}, ${esc(d.specialty)} (${d.open_issues} open)</option>`).join('');
    openDialog(assignDialog, button);
  });

  assignForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    clearErrors(assignForm);
    const errors = checkForm(assignForm);
    if (Object.keys(errors).length) return showErrors(assignForm, errors);
    const done = busy(document.getElementById('assign-save'), 'Assigning…');
    try {
      const result = await api(`/api/issues/${assigning.id}/assign`, 'POST', getValues(assignForm));
      assignDialog.close();
      showMessage(result.message);
      loadIssues();
    } catch (err) {
      showErrors(assignForm, err.fields, err.message);
    } finally {
      done();
    }
  });
}

// ---------- patient: describe a new issue ----------

const issueDialog = document.getElementById('issue-dialog');
if (issueDialog) {
  const form = document.getElementById('issue-form');
  lists = await api('/api/lists');
  form.elements.urgency.innerHTML = '<option value="">Select one</option>' + lists.urgency.map((u) => `<option>${esc(u)}</option>`).join('');

  // Extra field: the patient's name, only when asking for a family member
  form.addEventListener('change', (e) => {
    if (e.target.name === 'for_whom') showIf(document.getElementById('patient-section'), e.target.value === 'A family member');
  });

  document.getElementById('add-button').addEventListener('click', (e) => {
    form.reset();
    clearErrors(form);
    showIf(document.getElementById('patient-section'), false);
    openDialog(issueDialog, e.currentTarget);
  });

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    clearErrors(form);
    const errors = checkForm(form);
    if (Object.keys(errors).length) return showErrors(form, errors);
    const done = busy(document.getElementById('issue-save'), 'Sending…');
    try {
      const result = await api('/api/issues', 'POST', getValues(form));
      window.location.href = `/issue?id=${result.id}&sent`;
    } catch (err) {
      done();
      showErrors(form, err.fields, err.message);
    }
  });
}

loadIssues();
