// Send feedback page. Anyone can use it; signed-in people do not need to type their name.
import { api, esc, getValues, checkForm, showErrors, clearErrors, showIf, busy, showMessage } from './main.js';

const form = document.getElementById('feedback-form');
const nameSection = document.getElementById('name-section');
const sendingAs = document.getElementById('sending-as');

// Signed in? Use the account name instead of asking for it.
async function checkSignedIn() {
  try {
    const { user: me } = await api('/api/session');
    if (!me) return;
    showIf(nameSection, false);
    sendingAs.innerHTML = `You are sending this as <strong>${esc(me.full_name)}</strong>.`;
    sendingAs.hidden = false;
  } catch {
    // not signed in, or offline: keep the name field
  }
}

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  clearErrors(form);
  const errors = checkForm(form);
  if (Object.keys(errors).length) return showErrors(form, errors);

  const done = busy(document.getElementById('feedback-save'), 'Sending…');
  try {
    const result = await api('/api/feedback', 'POST', getValues(form));
    form.reset();
    showMessage(result.message);
  } catch (err) {
    if (Object.keys(err.fields || {}).length) showErrors(form, err.fields, err.message);
    else showMessage(err.message, 'error');
  } finally {
    done();
  }
});

checkSignedIn();
