// Admin equipment page: search, filter, sort, add, edit and delete equipment, with stock counts and photos.
import { api, esc, formatDate, badge, showMessage, announce, getValues, checkForm, showErrors, clearErrors,
  showIf, busy, openDialog, setupPage, pictureFor, stockBadge } from './main.js';

setupPage();

const rows = document.getElementById('rows');
const filters = document.getElementById('filters');
const itemDialog = document.getElementById('item-dialog');
const itemForm = document.getElementById('item-form');
const deleteDialog = document.getElementById('delete-dialog');
const photoInput = document.getElementById('item-photo');

let lists = {};
let items = [];
let editing = null;
let sort = { column: 'name', order: 'asc' };
let deleting = null;

// The dashboard links here with ?stock=... or ?search=...
const params = new URLSearchParams(location.search);
filters.search.value = params.get('search') || '';
filters.stock.value = params.get('stock') || '';

async function loadItems() {
  const query = new URLSearchParams({
    search: filters.search.value.trim(), category: filters.category.value, stock: filters.stock.value,
    sort: sort.column, order: sort.order
  });
  rows.innerHTML = '<tr><td colspan="7" class="empty">Loading equipment…</td></tr>';
  try {
    items = await api('/api/equipment?' + query);
  } catch (err) {
    rows.innerHTML = '<tr><td colspan="7" class="empty">Equipment could not be loaded.</td></tr>';
    return showMessage(err.message, 'error');
  }

  const results = document.getElementById('results');
  if (items.length === 0) {
    rows.innerHTML = '<tr><td colspan="7" class="empty">No equipment matches your search. Try different words or clear the filters.</td></tr>';
    results.textContent = 'No matching equipment.';
  } else {
    rows.innerHTML = items.map((item) => `<tr>
      <td class="code">${item.code}</td>
      <th scope="row"><span class="name-with-photo"><img src="${pictureFor(item)}" alt="" width="48" height="30" loading="lazy">
        <span>${esc(item.name)}<span class="sub">${esc(item.description)}</span></span></span></th>
      <td>${esc(item.category)}</td>
      <td>${stockBadge(item)}<span class="sub">${item.quantity} owned · ${item.on_loan} on loan · ${item.reserved} requested</span></td>
      <td>${item.in_repair ? `${badge('In repair')} ${item.in_repair}<span class="sub">${esc(item.repair_notes)}</span>` : 'None'}</td>
      <td>${formatDate(item.date_added)}</td>
      <td class="cell-actions">
        <button type="button" class="btn btn-secondary btn-small" data-edit="${item.id}">Edit<span class="visually-hidden"> ${esc(item.name)}</span></button>
        <button type="button" class="btn btn-danger btn-small" data-delete="${item.id}">Delete<span class="visually-hidden"> ${esc(item.name)}</span></button>
      </td>
    </tr>`).join('');
    const units = items.reduce((sum, i) => sum + Math.max(0, i.in_stock), 0);
    results.textContent = `Showing ${items.length} item${items.length === 1 ? '' : 's'}, ${units} unit${units === 1 ? '' : 's'} in stock.`;
  }
  announce(results.textContent);

  // Show which column is sorted, for sighted and screen reader users
  document.querySelectorAll('th[data-sort]').forEach((th) => {
    const active = th.dataset.sort === sort.column;
    th.querySelector('.sort-icon').textContent = active ? (sort.order === 'asc' ? '▲' : '▼') : '↕';
    if (active) th.setAttribute('aria-sort', sort.order === 'asc' ? 'ascending' : 'descending');
    else th.removeAttribute('aria-sort');
  });
}

// ---------- search, filter, sort ----------

let typingTimer;
filters.addEventListener('input', (e) => {
  clearTimeout(typingTimer);
  typingTimer = setTimeout(loadItems, e.target.type === 'search' ? 300 : 0);
});
filters.addEventListener('submit', (e) => { e.preventDefault(); loadItems(); });
filters.addEventListener('reset', () => setTimeout(loadItems));

document.querySelectorAll('th[data-sort] button').forEach((button) => {
  button.addEventListener('click', () => {
    const column = button.parentElement.dataset.sort;
    sort.order = sort.column === column && sort.order === 'asc' ? 'desc' : 'asc';
    sort.column = column;
    loadItems();
  });
});

// ---------- add and edit ----------

const repairInput = itemForm.elements.in_repair;
const updateRepairSection = () => showIf(document.getElementById('repair-section'), Number(repairInput.value) > 0);
repairInput.addEventListener('input', updateRepairSection);

function openItemForm(item, button) {
  editing = item;
  itemForm.reset();
  clearErrors(itemForm);
  document.getElementById('item-title').textContent = item ? `Edit ${item.name}` : 'Add equipment';
  itemForm.elements.id.value = item ? item.id : '';
  itemForm.elements.name.value = item ? item.name : '';
  itemForm.elements.category.value = item ? item.category : '';
  itemForm.elements.description.value = item ? item.description : '';
  itemForm.elements.how_to_use.value = item ? item.how_to_use : '';
  itemForm.elements.quantity.value = item ? item.quantity : 1;
  repairInput.value = item ? item.in_repair : 0;
  itemForm.elements.repair_notes.value = item ? item.repair_notes : '';
  updateRepairSection();

  // Show the current photo, with the option to remove it
  const current = document.getElementById('current-photo');
  current.hidden = !(item && item.photo_version);
  if (!current.hidden) document.getElementById('photo-preview').src = pictureFor(item);
  openDialog(itemDialog, button);
}

// Read the chosen photo as base64 text so it can be sent with the rest of the form
function readPhoto(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve({ type: file.type, data: String(reader.result).split(',')[1] });
    reader.onerror = () => reject(new Error('The photo could not be read. Try another file.'));
    reader.readAsDataURL(file);
  });
}

itemForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  clearErrors(itemForm);
  const values = getValues(itemForm);
  delete values.photo_file;
  values.remove_photo = itemForm.elements.remove_photo.checked;
  const errors = checkForm(itemForm);
  const owned = Number(values.quantity);
  const repair = Number(values.in_repair);
  if (!errors.quantity && (!Number.isInteger(owned) || owned < 1 || owned > 99)) errors.quantity = 'Enter how many you own, from 1 to 99.';
  if (!errors.in_repair && (!Number.isInteger(repair) || repair < 0 || repair > owned)) errors.in_repair = 'Units in repair must be between 0 and the number you own.';

  const file = photoInput.files[0];
  if (file && !['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) errors.photo_file = 'The photo must be a JPG, PNG or WebP image.';
  else if (file && file.size > 2 * 1024 * 1024) errors.photo_file = 'The photo must be 2 MB or smaller.';
  if (Object.keys(errors).length) return showErrors(itemForm, errors);

  const done = busy(document.getElementById('item-save'), 'Saving…');
  try {
    if (file) values.photo = await readPhoto(file);
    const result = values.id
      ? await api('/api/equipment/' + values.id, 'PUT', values)
      : await api('/api/equipment', 'POST', values);
    itemDialog.close();
    showMessage(result.message);
    loadItems();
  } catch (err) {
    // The server calls the photo field "photo"; the input is named photo_file
    if (err.fields && err.fields.photo) err.fields.photo_file = err.fields.photo;
    delete (err.fields || {}).photo;
    showErrors(itemForm, err.fields, err.message);
  } finally {
    done();
  }
});

// ---------- delete ----------

function askToDelete(item, button) {
  if (item.on_loan + item.reserved > 0) {
    return showMessage(`${item.name} has units on loan or requested. Finish those on the Loans page before deleting it.`, 'error');
  }
  deleting = item;
  document.getElementById('delete-text').textContent = `Delete ${item.name} (${item.code}) and all ${item.quantity} units? This cannot be undone.`;
  openDialog(deleteDialog, button);
}

document.getElementById('delete-confirm').addEventListener('click', async (e) => {
  const done = busy(e.currentTarget, 'Deleting…');
  try {
    const result = await api('/api/equipment/' + deleting.id, 'DELETE');
    deleteDialog.opener = document.querySelector('h1'); // the row is gone, so move focus to the heading
    deleteDialog.close();
    showMessage(result.message);
    loadItems();
  } catch (err) {
    deleteDialog.close();
    showMessage(err.message, 'error');
  } finally {
    done();
  }
});

// ---------- buttons in the table ----------

rows.addEventListener('click', (e) => {
  const button = e.target.closest('button');
  if (!button) return;
  const item = items.find((i) => i.id === Number(button.dataset.edit || button.dataset.delete));
  if (button.dataset.edit) openItemForm(item, button);
  if (button.dataset.delete) askToDelete(item, button);
});

document.getElementById('add-button').addEventListener('click', (e) => openItemForm(null, e.currentTarget));

// ---------- start ----------

lists = await api('/api/lists');
const categoryOptions = lists.categories.map((c) => `<option>${esc(c)}</option>`).join('');
filters.category.insertAdjacentHTML('beforeend', categoryOptions);
itemForm.elements.category.innerHTML = '<option value="">Select a category</option>' + categoryOptions;
loadItems();
