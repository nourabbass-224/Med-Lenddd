// User "My loans" page: requests waiting for approval, what is on loan now, and past loans.
import { api, esc, formatDate, badge, showMessage, busy, setupPage, howToUse } from './main.js';

setupPage();

function dueText(l) {
  if (l.status !== 'Overdue') return formatDate(l.due_date);
  return `${formatDate(l.due_date)}<span class="sub">${l.days_overdue} day${l.days_overdue === 1 ? '' : 's'} late. Please return it.</span>`;
}

// One small table per section; `columns` lists the headings and `cells` builds a row
function table(label, columns, loans, cells) {
  return `<div class="table-wrap" role="region" aria-label="${label}" tabindex="0">
    <table>
      <thead><tr>${columns.map((c) => `<th scope="col">${c}</th>`).join('')}</tr></thead>
      <tbody>${loans.map((l) => `<tr>${cells(l)}</tr>`).join('')}</tbody>
    </table>
  </div>`;
}

const nameCell = (l) => `<th scope="row">${esc(l.equipment_name)}<span class="sub">${l.code}</span></th>`;

async function load() {
  let loans;
  try {
    loans = await api('/api/my-loans');
  } catch (err) {
    return showMessage(err.message, 'error');
  }
  const requests = loans.filter((l) => l.status === 'Requested');
  const current = loans.filter((l) => l.status === 'On loan' || l.status === 'Overdue');
  const past = loans.filter((l) => ['Returned', 'Declined', 'Cancelled'].includes(l.status));

  document.getElementById('requests').innerHTML = requests.length
    ? table('Requests waiting', ['Equipment', 'Requested on', 'Return by', 'Status', 'Actions'], requests, (l) => `
        ${nameCell(l)}<td>${formatDate(l.loan_date)}</td><td>${formatDate(l.due_date)}</td><td>${badge(l.status)}</td>
        <td><button type="button" class="btn btn-secondary btn-small" data-cancel="${l.id}">Cancel request<span class="visually-hidden"> for ${esc(l.equipment_name)}</span></button></td>`)
    : '<p class="empty">You have no requests waiting. <a href="/borrow">Request equipment</a></p>';

  document.getElementById('current').innerHTML = current.length
    ? table('Currently borrowed', ['Equipment', 'Borrowed', 'Due back', 'Status'], current, (l) => `
        ${nameCell(l)}<td>${formatDate(l.loan_date)}</td><td>${dueText(l)}</td><td>${badge(l.status)}</td>`)
      + `<div class="how-to-list">${current.map((l) => howToUse(l, l.equipment_name, true)).join('')}</div>`
    : '<p class="empty">You have nothing on loan.</p>';

  document.getElementById('past').innerHTML = past.length
    ? table('History', ['Equipment', 'Date', 'Status', 'Details'], past, (l) => `
        ${nameCell(l)}<td>${formatDate(l.return_date || l.loan_date)}</td><td>${badge(l.status)}</td>
        <td>${l.status === 'Declined' ? 'Reason: ' + esc(l.decline_reason) : l.status === 'Returned' ? 'Returned in ' + esc(l.return_condition.toLowerCase()) + ' condition' : 'You cancelled this request'}</td>`)
    : '<p class="empty">Nothing here yet.</p>';
}

// Cancel a request that is still waiting
document.getElementById('requests').addEventListener('click', async (e) => {
  const button = e.target.closest('button[data-cancel]');
  if (!button) return;
  const done = busy(button, 'Cancelling…');
  try {
    const result = await api(`/api/my-loans/${button.dataset.cancel}/cancel`, 'POST');
    showMessage(result.message);
    document.querySelector('h1').focus(); // the button is gone after cancelling
    load();
  } catch (err) {
    done();
    showMessage(err.message, 'error');
  }
});

load();
