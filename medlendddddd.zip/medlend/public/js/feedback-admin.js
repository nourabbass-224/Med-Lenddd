// Admin feedback page: read what people have sent and mark it as dealt with.
import { api, esc, formatDateTime, badge, showMessage, announce, setupPage } from './main.js';

setupPage();

const list = document.getElementById('feedback-list');
const results = document.getElementById('results');
const filters = document.getElementById('filters');

// The dashboard links here with ?status=New
const startStatus = new URLSearchParams(location.search).get('status');
if (startStatus) {
  const radio = filters.querySelector(`input[value="${CSS.escape(startStatus)}"]`);
  if (radio) radio.checked = true;
}

// "patient", "doctor" or "visitor" (not signed in)
function who(item) {
  if (item.role === 'user') return `patient, @${item.username}`;
  if (item.role === 'doctor') return `doctor, @${item.username}`;
  if (item.role === 'admin') return `equipment desk, @${item.username}`;
  return 'not signed in';
}

async function load() {
  const status = filters.elements.status.value;
  let items;
  try {
    items = await api('/api/feedback?status=' + encodeURIComponent(status));
  } catch (err) {
    return showMessage(err.message, 'error');
  }

  if (items.length === 0) {
    list.innerHTML = '';
    results.textContent = status ? `No feedback marked "${status}".` : 'No feedback yet. Messages sent from the Send feedback page appear here.';
  } else {
    list.innerHTML = items.map((f) => `<li>
      <article class="feedback-item${f.status === 'New' ? ' is-new' : ''}" aria-labelledby="fb-${f.id}-title">
        <div class="feedback-top">
          <h3 id="fb-${f.id}-title">${esc(f.topic)} <span class="sub-inline">${f.code}</span></h3>
          ${badge(f.status)}
        </div>
        <p class="sub">From ${esc(f.name)} (${esc(who(f))}) · ${formatDateTime(f.created_at)}${f.page ? ` · Page: ${esc(f.page)}` : ''}</p>
        <p class="feedback-message">${esc(f.message)}</p>
        ${f.contact ? `<p class="sub">Reply to: ${esc(f.contact)}</p>` : ''}
        <button type="button" class="btn btn-secondary btn-small" data-id="${f.id}" data-status="${f.status === 'New' ? 'Dealt with' : 'New'}">
          ${f.status === 'New' ? 'Mark as dealt with' : 'Mark as new'}<span class="visually-hidden"> ${f.code}</span>
        </button>
      </article>
    </li>`).join('');
    const newCount = items.filter((f) => f.status === 'New').length;
    results.textContent = `Showing ${items.length} message${items.length === 1 ? '' : 's'}, ${newCount} new.`;
  }
  announce(results.textContent);
}

filters.addEventListener('change', load);
filters.addEventListener('submit', (e) => e.preventDefault());

list.addEventListener('click', async (e) => {
  const button = e.target.closest('button[data-id]');
  if (!button) return;
  const id = button.dataset.id;
  button.disabled = true;
  try {
    const result = await api(`/api/feedback/${id}/status`, 'PUT', { status: button.dataset.status });
    showMessage(result.message);
    await load();
    // Keep focus on the same message if it is still shown, otherwise go to the page heading
    const again = list.querySelector(`button[data-id="${id}"]`);
    (again || document.querySelector('h1')).focus();
  } catch (err) {
    button.disabled = false;
    showMessage(err.message, 'error');
  }
});

load();
