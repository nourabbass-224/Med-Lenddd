// Admin doctors page: list doctors, add a doctor account, and suspend or reactivate accounts.
import { api, esc, badge, showMessage, announce, getValues, checkForm, showErrors, clearErrors, busy, openDialog, setupPage } from './main.js';
import { setupAccountStatus } from './account-status.js';

setupPage();

const rows = document.getElementById('rows');
const dialog = document.getElementById('doctor-dialog');
const form = document.getElementById('doctor-form');
let doctors = [];

async function loadDoctors() {
  try {
    doctors = await api('/api/doctors');
  } catch (err) {
    return showMessage(err.message, 'error');
  }
  const results = document.getElementById('results');
  if (doctors.length === 0) {
    rows.innerHTML = '<tr><td colspan="7" class="empty">No doctors yet. Add one so patients can get advice.</td></tr>';
    results.textContent = 'No doctors yet.';
  } else {
    rows.innerHTML = doctors.map((d) => `<tr>
      <td class="code">${d.code}</td>
      <th scope="row">${esc(d.full_name)}<span class="sub">@${esc(d.username)}</span></th>
      <td>${esc(d.specialty)}</td>
      <td>${esc(d.phone)}</td>
      <td>${d.open_issues} open<span class="sub">${d.total_issues} in total</span></td>
      <td>${badge(d.active ? 'Active' : 'Suspended')}</td>
      <td><button type="button" class="btn ${d.active ? 'btn-danger' : 'btn-secondary'} btn-small" data-status="${d.id}">${d.active ? 'Suspend' : 'Reactivate'}<span class="visually-hidden"> ${esc(d.full_name)}</span></button></td>
    </tr>`).join('');
    results.textContent = `${doctors.length} doctor${doctors.length === 1 ? '' : 's'}.`;
  }
  announce(results.textContent);
}

const changeStatus = setupAccountStatus(loadDoctors);
rows.addEventListener('click', (e) => {
  const button = e.target.closest('button[data-status]');
  if (button) changeStatus(doctors.find((d) => d.id === Number(button.dataset.status)), button);
});

// ---------- add a doctor ----------

document.getElementById('add-button').addEventListener('click', (e) => {
  form.reset();
  clearErrors(form);
  openDialog(dialog, e.currentTarget);
});

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  clearErrors(form);
  const values = getValues(form);
  const errors = checkForm(form);
  const strong = values.password.length >= 8 && /[A-Za-z]/.test(values.password) && /\d/.test(values.password);
  if (!errors.password && !strong) errors.password = 'Password must be at least 8 characters and include a letter and a number.';
  if (Object.keys(errors).length) return showErrors(form, errors);

  const done = busy(document.getElementById('doctor-save'), 'Adding…');
  try {
    const result = await api('/api/doctors', 'POST', values);
    dialog.close();
    showMessage(result.message);
    loadDoctors();
  } catch (err) {
    showErrors(form, err.fields, err.message);
  } finally {
    done();
  }
});

const lists = await api('/api/lists');
form.elements.specialty.innerHTML = '<option value="">Select a specialty</option>' + lists.specialties.map((s) => `<option>${esc(s)}</option>`).join('');
loadDoctors();
