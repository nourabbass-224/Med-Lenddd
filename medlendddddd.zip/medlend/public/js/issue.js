// One patient issue and its conversation.
//   patient – reads the doctor's advice, requests recommended equipment, replies or closes the issue
//   doctor  – replies with advice and ticks the equipment to recommend
//   admin   – assigns or changes the doctor, or closes the issue
import { api, esc, formatDate, formatDateTime, badge, showMessage, announce, getValues, checkForm, showErrors,
  clearErrors, busy, setupPage, pictureFor, stockBadge } from './main.js';

const me = await setupPage();
const id = Number(new URLSearchParams(location.search).get('id'));
if (location.search.includes('sent')) showMessage('Your issue was sent. The equipment desk will pass it to a doctor and you will see the answer here.');

let issue = null;

function recommendedList(items) {
  if (!items.length) return '';
  return `<div class="recommended">
    <h4>Recommended equipment</h4>
    <ul class="recommended-list">${items.map((item) => `<li>
      <img src="${pictureFor(item)}" alt="" width="64" height="40">
      <span class="recommended-name">${esc(item.name)}<span class="sub">${esc(item.category)}</span></span>
      ${stockBadge(item)}
      ${me.role === 'user' && item.in_stock > 0 && issue.status !== 'Closed'
        ? `<a class="btn btn-primary btn-small" href="/borrow?item=${item.id}">Request<span class="visually-hidden"> ${esc(item.name)}</span></a>` : ''}
    </li>`).join('')}</ul>
  </div>`;
}

const ROLE_NAMES = { admin: 'Equipment desk', doctor: 'Doctor', user: 'Patient' };

function render() {
  document.title = `${issue.subject} – Med Lend`;
  document.getElementById('issue-subject').textContent = issue.subject;
  document.getElementById('intro').innerHTML = `${issue.code} · sent ${formatDate(issue.created_at.slice(0, 10))} · ${badge(issue.status)}`;

  const facts = [
    ['Patient', issue.patient_name ? `${esc(issue.patient_name)} (asked by ${esc(issue.patient_account_name)})` : esc(issue.patient_account_name)],
    ['Phone', esc(issue.patient_phone)],
    ['How soon', issue.urgency === 'Urgent' ? badge('Urgent') : esc(issue.urgency)],
    ['Doctor', issue.doctor_name ? `${esc(issue.doctor_name)}, ${esc(issue.doctor_specialty)}` : 'Not assigned yet']
  ];
  if (me.role === 'user') facts.splice(1, 1); // patients know their own phone number
  document.getElementById('issue-facts').innerHTML = facts.map(([t, d]) => `<dt>${t}</dt><dd>${d}</dd>`).join('');
  document.getElementById('issue-details').textContent = issue.details;

  document.getElementById('messages').innerHTML = issue.messages.length
    ? issue.messages.map((m) => `<li class="message message-${m.author_role}">
        <article aria-label="Message from ${esc(m.author)}">
          <h3>${esc(m.author)} <span class="message-role">${ROLE_NAMES[m.author_role]}${m.specialty ? ', ' + esc(m.specialty) : ''}</span></h3>
          <p class="sub"><time datetime="${m.created_at}">${formatDateTime(m.created_at)}</time></p>
          <p class="message-body">${esc(m.body)}</p>
          ${recommendedList(m.recommended)}
        </article>
      </li>`).join('')
    : `<li class="empty">${issue.doctor_name ? `Waiting for ${esc(issue.doctor_name)} to reply.` : 'Waiting for the equipment desk to assign a doctor.'}</li>`;

  // Nothing more can be sent once an issue is closed
  const panel = document.getElementById('reply-panel');
  if (issue.status === 'Closed') {
    panel.innerHTML = '<h2>This issue is closed</h2><p>Need more help? Describe a new issue on the Ask a doctor page.</p>';
  }
}

async function load() {
  try {
    issue = await api('/api/issues/' + id);
    render();
  } catch (err) {
    document.getElementById('issue-subject').textContent = 'Issue not found';
    document.getElementById('intro').textContent = err.message;
    document.getElementById('reply-panel').hidden = true;
  }
}

// ---------- doctor: list equipment to recommend, grouped by category ----------

async function loadRecommendOptions() {
  const box = document.getElementById('recommend-list');
  if (!box) return;
  const equipment = await api('/api/equipment?sort=category');
  const groups = {};
  for (const item of equipment) (groups[item.category] ||= []).push(item);
  box.innerHTML = Object.entries(groups).map(([category, items]) => `<fieldset class="recommend-group">
      <legend>${esc(category)}</legend>
      ${items.map((item) => `<label class="checkbox"><input type="checkbox" name="equipment_ids" value="${item.id}">
        ${esc(item.name)} <span class="sub-inline">(${item.in_stock > 0 ? item.in_stock + ' in stock' : 'out of stock'})</span></label>`).join('')}
    </fieldset>`).join('');
}

// ---------- reply (patient or doctor) ----------

const replyForm = document.getElementById('reply-form');
if (replyForm) {
  replyForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    clearErrors(replyForm);
    const errors = checkForm(replyForm);
    if (Object.keys(errors).length) return showErrors(replyForm, errors);
    const body = { message: replyForm.elements.message.value };
    if (me.role === 'doctor') body.equipment_ids = [...replyForm.querySelectorAll('input[name=equipment_ids]:checked')].map((c) => c.value);

    const done = busy(document.getElementById('reply-save'), 'Sending…');
    try {
      const result = await api(`/api/issues/${id}/messages`, 'POST', body);
      replyForm.reset();
      showMessage(result.message);
      await load();
      announce('The conversation has been updated.');
    } catch (err) {
      if (err.fields && err.fields.equipment_ids) {
        const box = document.getElementById('recommend-error');
        box.textContent = err.fields.equipment_ids;
        box.hidden = false;
      }
      showErrors(replyForm, err.fields, err.message);
    } finally {
      done();
    }
  });
}

// ---------- admin: assign a doctor ----------

const assignForm = document.getElementById('assign-form');
if (assignForm) {
  assignForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    clearErrors(assignForm);
    const errors = checkForm(assignForm);
    if (Object.keys(errors).length) return showErrors(assignForm, errors);
    const done = busy(document.getElementById('assign-save'), 'Assigning…');
    try {
      const result = await api(`/api/issues/${id}/assign`, 'POST', getValues(assignForm));
      showMessage(result.message);
      load();
    } catch (err) {
      showErrors(assignForm, err.fields, err.message);
    } finally {
      done();
    }
  });
}

// ---------- patient or admin: close the issue ----------

const closeButton = document.getElementById('close-issue');
if (closeButton) {
  closeButton.addEventListener('click', async () => {
    const done = busy(closeButton, 'Closing…');
    try {
      const result = await api(`/api/issues/${id}/close`, 'POST');
      showMessage(result.message);
      await load();
      document.querySelector('h1').focus(); // the button is gone once the issue is closed
    } catch (err) {
      done();
      showMessage(err.message, 'error');
    }
  });
}

// ---------- start ----------

await load();
if (me.role === 'doctor' && issue) loadRecommendOptions();
if (me.role === 'admin' && issue && assignForm) {
  const doctors = (await api('/api/doctors')).filter((d) => d.active);
  assignForm.elements.doctor_id.innerHTML = '<option value="">Select a doctor</option>' +
    doctors.map((d) => `<option value="${d.id}"${d.id === issue.doctor_id ? ' selected' : ''}>${esc(d.full_name)}, ${esc(d.specialty)}</option>`).join('');
}
