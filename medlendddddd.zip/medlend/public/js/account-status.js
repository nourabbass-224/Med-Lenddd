// Suspend or reactivate a patient or doctor account. Used by the Patients and Doctors pages.
// Suspending asks first in the "status" pop-up; reactivating happens straight away.
import { api, showMessage, openDialog, busy } from './main.js';

export function setupAccountStatus(reload) {
  const dialog = document.getElementById('status-dialog');
  let changing = null;

  async function save(account, active, button) {
    const done = busy(button, active ? 'Reactivating…' : 'Suspending…');
    try {
      const result = await api(`/api/accounts/${account.id}/status`, 'PUT', { active });
      dialog.opener = document.querySelector('h1'); // the button changes, so move focus to the heading
      if (dialog.open) dialog.close();
      showMessage(result.message);
      document.querySelector('h1').focus();
      reload();
    } catch (err) {
      done();
      showMessage(err.message, 'error');
    }
  }

  document.getElementById('status-confirm').addEventListener('click', (e) => save(changing, false, e.currentTarget));

  return function changeStatus(account, button) {
    if (!account.active) return save(account, true, button);
    changing = account;
    document.getElementById('status-text').textContent =
      `${account.full_name} will be signed out and will not be able to sign in until you reactivate the account.`;
    openDialog(dialog, button);
  };
}
