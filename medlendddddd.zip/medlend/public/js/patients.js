// Admin patients page: everyone who has signed up, their loan history, and suspending accounts.
import { api, esc, formatDate, badge, showMessage, announce, openDialog, busy, setupPage } from './main.js';
import { setupAccountStatus } from './account-status.js';

setupPage();

const rows = document.getElementById('rows');
const search = document.getElementById('search');
let patients = [];

async function loadPatients() {
  const text = search.value.trim();
  try {
    patients = await api('/api/patients?search=' + encodeURIComponent(text));
  } catch (err) {
    return showMessage(err.message, 'error');
  }

  const results = document.getElementById('results');
  if (patients.length === 0) {
    const message = text ? `No patients match "${text}".` : 'No one has created an account yet. Patients appear here when they sign up.';
    rows.innerHTML = `<tr><td colspan="8" class="empty">${esc(message)}</td></tr>`;
    results.textContent = message;
  } else {
    rows.innerHTML = patients.map((p) => `<tr>
      <td class="code">${p.code}</td>
      <th scope="row">${esc(p.full_name)}<span class="sub">@${esc(p.username)}</span></th>
      <td>${esc(p.gender)}</td>
      <td>${esc(p.phone)}</td>
      <td>${formatDate(p.created_at)}</td>
      <td>${p.open_items} now${p.overdue ? ` ${badge('Overdue')}` : ''}<span class="sub">${p.total_loans} loans · ${p.issues} issues</span></td>
      <td>${badge(p.active ? 'Active' : 'Suspended')}</td>
      <td class="cell-actions">
        <button type="button" class="btn btn-secondary btn-small" data-history="${p.id}">Loan history<span class="visually-hidden"> for ${esc(p.full_name)}</span></button>
        <button type="button" class="btn ${p.active ? 'btn-danger' : 'btn-secondary'} btn-small" data-status="${p.id}">${p.active ? 'Suspend' : 'Reactivate'}<span class="visually-hidden"> ${esc(p.full_name)}</span></button>
      </td>
    </tr>`).join('');
    results.textContent = `Showing ${patients.length} patient${patients.length === 1 ? '' : 's'}.`;
  }
  announce(results.textContent);
}

let typingTimer;
search.addEventListener('input', () => {
  clearTimeout(typingTimer);
  typingTimer = setTimeout(loadPatients, 300);
});
document.getElementById('filters').addEventListener('submit', (e) => { e.preventDefault(); loadPatients(); });

const changeStatus = setupAccountStatus(loadPatients);

// ---------- loan history for one patient ----------

rows.addEventListener('click', async (e) => {
  const button = e.target.closest('button');
  if (!button) return;
  const patient = patients.find((p) => p.id === Number(button.dataset.history || button.dataset.status));
  if (button.dataset.status) return changeStatus(patient, button);

  const history = document.getElementById('history');
  document.getElementById('history-title').textContent = `Loan history: ${patient.full_name}`;
  history.innerHTML = '<p>Loading…</p>';
  openDialog(document.getElementById('history-dialog'), button);
  try {
    const loans = await api(`/api/patients/${patient.id}/loans`);
    history.innerHTML = loans.length === 0
      ? '<p class="empty">This patient has not borrowed anything yet.</p>'
      : `<div class="table-wrap" role="region" aria-label="Loans" tabindex="0"><table>
          <thead><tr><th scope="col">Loan</th><th scope="col">Equipment</th><th scope="col">Borrowed</th><th scope="col">Due back</th><th scope="col">Returned</th><th scope="col">Status</th></tr></thead>
          <tbody>${loans.map((l) => `<tr>
            <td class="code">${l.code}</td>
            <td>${esc(l.equipment_name)}</td>
            <td>${formatDate(l.loan_date)}</td>
            <td>${formatDate(l.due_date)}</td>
            <td>${l.return_date ? formatDate(l.return_date) + `<span class="sub">${esc(l.return_condition)}</span>` : (l.status === 'On loan' || l.status === 'Overdue' ? 'Not yet' : '—')}</td>
            <td>${badge(l.status)}</td>
          </tr>`).join('')}</tbody>
        </table></div>`;
  } catch (err) {
    history.innerHTML = `<p>${esc(err.message)}</p>`;
  }
});

loadPatients();
