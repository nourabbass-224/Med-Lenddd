// Admin loans page: approve or decline requests, record returns, and record loans made at the desk.
import { api, esc, formatDate, badge, showMessage, announce, getValues, checkForm, showErrors, clearErrors,
  showIf, busy, openDialog, setupPage } from './main.js';

setupPage();

const rows = document.getElementById('rows');
const filters = document.getElementById('filters');
const loanDialog = document.getElementById('loan-dialog');
const loanForm = document.getElementById('loan-form');
const returnDialog = document.getElementById('return-dialog');
const returnForm = document.getElementById('return-form');
const declineDialog = document.getElementById('decline-dialog');
const declineForm = document.getElementById('decline-form');

let lists = {};
let loans = [];
let returning = null;
let declining = null;

// The dashboard links here with ?status=Requested, ?status=Overdue or ?status=On loan
const startStatus = new URLSearchParams(location.search).get('status');
if (startStatus) filters.status.value = startStatus;

// What can be done with a loan depends on its status
function actionsFor(l) {
  const what = `<span class="visually-hidden"> ${esc(l.equipment_name)} for ${esc(l.borrower_name)}</span>`;
  if (l.status === 'Requested') {
    return `<button type="button" class="btn btn-primary btn-small" data-approve="${l.id}">Approve${what}</button>
      <button type="button" class="btn btn-secondary btn-small" data-decline="${l.id}">Decline${what}</button>`;
  }
  if (l.status === 'On loan' || l.status === 'Overdue') {
    return `<button type="button" class="btn btn-primary btn-small" data-return="${l.id}">Record return${what}</button>`;
  }
  if (l.status === 'Returned') return `Returned ${formatDate(l.return_date)}<span class="sub">${esc(l.return_condition)}</span>`;
  if (l.status === 'Declined') return `<span class="sub">${esc(l.decline_reason)}</span>`;
  return '<span class="sub">Cancelled by the borrower</span>';
}

async function loadLoans() {
  const status = filters.status.value;
  const search = filters.search.value.trim();
  rows.innerHTML = '<tr><td colspan="7" class="empty">Loading loans…</td></tr>';
  try {
    loans = await api(`/api/loans?status=${encodeURIComponent(status)}&search=${encodeURIComponent(search)}`);
  } catch (err) {
    return showMessage(err.message, 'error');
  }

  const results = document.getElementById('results');
  if (loans.length === 0) {
    const message = search || status ? 'No loans match these filters.' : 'No loans yet. They appear here when a patient requests equipment.';
    rows.innerHTML = `<tr><td colspan="7" class="empty">${message}</td></tr>`;
    results.textContent = message;
  } else {
    rows.innerHTML = loans.map((l) => `<tr>
      <td class="code">${l.code}</td>
      <td>${esc(l.equipment_name)}<span class="sub">${l.equipment_code}</span></td>
      <td>${esc(l.borrower_name)}<span class="sub">${esc(l.borrower_phone)}</span></td>
      <td>${formatDate(l.loan_date)}<span class="sub">${esc(l.purpose)}${l.delivery_address ? ': ' + esc(l.delivery_address) : ''}</span></td>
      <td>${formatDate(l.due_date)}${l.status === 'Overdue' ? `<span class="sub">${l.days_overdue} day${l.days_overdue === 1 ? '' : 's'} late</span>` : ''}</td>
      <td>${badge(l.status)}</td>
      <td class="cell-actions">${actionsFor(l)}</td>
    </tr>`).join('');
    results.textContent = `Showing ${loans.length} loan${loans.length === 1 ? '' : 's'}.`;
  }
  announce(results.textContent);
}

let typingTimer;
filters.addEventListener('input', (e) => {
  clearTimeout(typingTimer);
  typingTimer = setTimeout(loadLoans, e.target.type === 'search' ? 300 : 0);
});
filters.addEventListener('submit', (e) => { e.preventDefault(); loadLoans(); });

// ---------- record a loan at the desk ----------

const purpose = loanForm.elements.purpose;
purpose.addEventListener('change', () => {
  showIf(document.getElementById('address-section'), purpose.value === 'Home care with delivery');
});

document.getElementById('add-button').addEventListener('click', async (e) => {
  loanForm.reset();
  clearErrors(loanForm);
  showIf(document.getElementById('address-section'), false);
  loanForm.elements.loan_date.value = lists.today;
  loanForm.elements.loan_date.max = lists.today;
  loanForm.elements.due_date.value = lists.defaultDueDate;
  openDialog(loanDialog, e.currentTarget);

  const [patients, available] = await Promise.all([api('/api/patients'), api('/api/equipment?stock=In stock')]);
  loanForm.elements.user_id.innerHTML = patients.length
    ? '<option value="">Select a patient</option>' + patients.filter((p) => p.active).map((p) => `<option value="${p.id}">${esc(p.full_name)} (${esc(p.phone)})</option>`).join('')
    : '<option value="">No patients have signed up yet</option>';
  loanForm.elements.equipment_id.innerHTML = available.length
    ? '<option value="">Select equipment</option>' + available.map((i) => `<option value="${i.id}">${esc(i.name)} (${i.code}) – ${i.in_stock} in stock</option>`).join('')
    : '<option value="">Nothing is in stock right now</option>';
});

loanForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  clearErrors(loanForm);
  const values = getValues(loanForm);
  const errors = checkForm(loanForm);
  if (!errors.due_date && values.due_date <= values.loan_date) errors.due_date = 'The return date must be after the loan date.';
  if (Object.keys(errors).length) return showErrors(loanForm, errors);

  const done = busy(document.getElementById('loan-save'), 'Saving…');
  try {
    const result = await api('/api/loans', 'POST', values);
    loanDialog.close();
    showMessage(result.message);
    loadLoans();
  } catch (err) {
    showErrors(loanForm, err.fields, err.message);
  } finally {
    done();
  }
});

// ---------- record a return ----------

const condition = returnForm.elements.return_condition;
condition.addEventListener('change', () => {
  showIf(document.getElementById('damage-section'), lists.needsAttention.includes(condition.value));
});

// Buttons in the table: approve, decline or record a return
rows.addEventListener('click', async (e) => {
  const button = e.target.closest('button');
  if (!button) return;
  if (button.dataset.approve) return approve(button);
  if (button.dataset.decline) return openDecline(button);
  if (!button.dataset.return) return;
  returning = loans.find((l) => l.id === Number(button.dataset.return));

  returnForm.reset();
  clearErrors(returnForm);
  showIf(document.getElementById('damage-section'), false);
  document.getElementById('return-title').textContent = `Return: ${returning.equipment_name}`;
  document.getElementById('return-info').textContent =
    `Borrowed by ${returning.borrower_name} on ${formatDate(returning.loan_date)}, due back ${formatDate(returning.due_date)}.`;
  returnForm.elements.return_date.value = lists.today;
  returnForm.elements.return_date.min = returning.loan_date;
  returnForm.elements.return_date.max = lists.today;
  openDialog(returnDialog, button);
});

returnForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  clearErrors(returnForm);
  const errors = checkForm(returnForm);
  if (Object.keys(errors).length) return showErrors(returnForm, errors);

  const done = busy(document.getElementById('return-save'), 'Saving…');
  try {
    const result = await api(`/api/loans/${returning.id}/return`, 'POST', getValues(returnForm));
    returnDialog.opener = document.querySelector('h1'); // the button is gone after the return
    returnDialog.close();
    showMessage(result.message);
    loadLoans();
  } catch (err) {
    showErrors(returnForm, err.fields, err.message);
  } finally {
    done();
  }
});

// ---------- approve and decline requests ----------

async function approve(button) {
  const loan = loans.find((l) => l.id === Number(button.dataset.approve));
  const done = busy(button, 'Approving…');
  try {
    const result = await api(`/api/loans/${loan.id}/approve`, 'POST');
    showMessage(result.message);
    document.querySelector('h1').focus(); // the button disappears once approved
    loadLoans();
  } catch (err) {
    done();
    showMessage(err.message, 'error');
  }
}

const reason = declineForm.elements.reason;
reason.addEventListener('change', () => showIf(document.getElementById('other-section'), reason.value === 'Other'));

function openDecline(button) {
  declining = loans.find((l) => l.id === Number(button.dataset.decline));
  declineForm.reset();
  clearErrors(declineForm);
  showIf(document.getElementById('other-section'), false);
  document.getElementById('decline-info').textContent =
    `${declining.borrower_name} asked for the ${declining.equipment_name} on ${formatDate(declining.loan_date)}.`;
  openDialog(declineDialog, button);
}

declineForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  clearErrors(declineForm);
  const errors = checkForm(declineForm);
  if (Object.keys(errors).length) return showErrors(declineForm, errors);

  const done = busy(document.getElementById('decline-save'), 'Declining…');
  try {
    const result = await api(`/api/loans/${declining.id}/decline`, 'POST', getValues(declineForm));
    declineDialog.opener = document.querySelector('h1');
    declineDialog.close();
    showMessage(result.message);
    loadLoans();
  } catch (err) {
    showErrors(declineForm, err.fields, err.message);
  } finally {
    done();
  }
});

// ---------- start ----------

lists = await api('/api/lists');
purpose.innerHTML = '<option value="">Select one</option>' + lists.purposes.map((p) => `<option>${esc(p)}</option>`).join('');
condition.innerHTML = lists.conditions.map((c) => `<option>${esc(c)}</option>`).join('');
reason.innerHTML = '<option value="">Select a reason</option>' + lists.declineReasons.map((r) => `<option>${esc(r)}</option>`).join('');
loadLoans();
