// Sign-in page: checks the form, signs in, then sends each person to their home page.
import { api, getValues, checkForm, showErrors, clearErrors, showMessage, busy } from './main.js';

const form = document.getElementById('login-form');
const homePage = { admin: '/dashboard', doctor: '/issues', user: '/borrow' };

if (location.search.includes('signedout')) showMessage('You have signed out.');

// "Show password" checkbox
document.querySelector('.show-password').addEventListener('change', (e) => {
  form.elements.password.type = e.target.checked ? 'text' : 'password';
});

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  clearErrors(form);

  const errors = checkForm(form);
  if (Object.keys(errors).length) return showErrors(form, errors);

  const done = busy(form.querySelector('[type=submit]'), 'Signing in…');
  try {
    const result = await api('/api/login', 'POST', getValues(form));
    window.location.href = homePage[result.role];
  } catch (err) {
    done();
    showErrors(form, err.fields, err.message);
  }
});
