// Patient borrow page: browse equipment, see what is in stock, and send a request to borrow an item.
import { api, esc, formatDate, showMessage, announce, getValues, checkForm, showErrors, clearErrors,
  showIf, busy, openDialog, setupPage, pictureFor, stockBadge, howToUse } from './main.js';

setupPage();

const list = document.getElementById('items');
const filters = document.getElementById('filters');
const dialog = document.getElementById('borrow-dialog');
const form = document.getElementById('borrow-form');

let lists = {};
let items = [];

const params = new URLSearchParams(location.search);
if (params.has('welcome')) showMessage('Your account has been created. You can now ask a doctor or borrow equipment.');

async function loadItems() {
  const query = new URLSearchParams({
    search: filters.search.value.trim(),
    category: filters.category.value,
    stock: filters.in_stock_only.checked ? 'In stock' : ''
  });
  try {
    items = await api('/api/equipment?' + query);
  } catch (err) {
    return showMessage(err.message, 'error');
  }

  const results = document.getElementById('results');
  if (items.length === 0) {
    list.innerHTML = '<li class="empty">No equipment matches your search. Try another word or category.</li>';
    results.textContent = 'No matching equipment.';
  } else {
    list.innerHTML = items.map((item) => `<li class="item-card">
      <img src="${pictureFor(item)}" alt="" width="160" height="100" loading="lazy">
      <h3>${esc(item.name)}</h3>
      <p class="sub">${esc(item.category)} · ${item.code}</p>
      <p>${esc(item.description)}</p>
      ${howToUse(item)}
      <div class="item-card-footer">
        ${stockBadge(item)}
        ${item.in_stock > 0
          ? `<button type="button" class="btn btn-primary btn-small" data-id="${item.id}">Request<span class="visually-hidden"> ${esc(item.name)}</span></button>`
          : ''}
      </div>
    </li>`).join('');
    const inStock = items.filter((i) => i.in_stock > 0).length;
    results.textContent = `${items.length} item${items.length === 1 ? '' : 's'} found, ${inStock} in stock.`;
  }
  announce(results.textContent);
}

// Warn the patient if something they borrowed is late
async function checkOverdue() {
  const mine = await api('/api/my-loans');
  const late = mine.filter((l) => l.status === 'Overdue');
  document.getElementById('overdue-warning').innerHTML = late.length
    ? `<div class="flash flash-error"><span aria-hidden="true">!</span><p>
        Please return ${late.map((l) => esc(l.equipment_name)).join(', ')}. It was due back ${formatDate(late[0].due_date)}.
        You cannot borrow anything else until it is returned. <a href="/my-loans">See my loans</a></p></div>`
    : '';
}

let typingTimer;
filters.addEventListener('input', (e) => {
  clearTimeout(typingTimer);
  typingTimer = setTimeout(loadItems, e.target.type === 'search' ? 300 : 0);
});
filters.addEventListener('submit', (e) => { e.preventDefault(); loadItems(); });

// ---------- request form ----------

const purpose = form.elements.purpose;
purpose.addEventListener('change', () => {
  showIf(document.getElementById('address-section'), purpose.value === 'Home care with delivery');
});

function openRequest(item, opener) {
  form.reset();
  clearErrors(form);
  showIf(document.getElementById('address-section'), false);
  document.getElementById('borrow-title').textContent = `Request: ${item.name}`;
  document.getElementById('borrow-info').textContent =
    `${item.code} · ${item.in_stock} in stock. One is held for you while the equipment desk reviews your request.`;
  form.elements.equipment_id.value = item.id;
  form.elements.due_date.value = lists.defaultDueDate;
  form.elements.due_date.min = lists.today;
  openDialog(dialog, opener);
}

list.addEventListener('click', (e) => {
  const button = e.target.closest('button[data-id]');
  if (button) openRequest(items.find((i) => i.id === Number(button.dataset.id)), button);
});

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  clearErrors(form);
  const values = getValues(form);
  const errors = checkForm(form);
  if (!errors.due_date && values.due_date <= lists.today) errors.due_date = 'The return date must be after today.';
  if (Object.keys(errors).length) return showErrors(form, errors);

  const done = busy(document.getElementById('borrow-save'), 'Sending request…');
  try {
    const result = await api('/api/my-loans', 'POST', values);
    dialog.opener = document.querySelector('h1');
    dialog.close();
    showMessage(result.message);
    loadItems();
  } catch (err) {
    showErrors(form, err.fields, err.message);
  } finally {
    done();
  }
});

// ---------- start ----------

lists = await api('/api/lists');
filters.category.insertAdjacentHTML('beforeend', lists.categories.map((c) => `<option>${esc(c)}</option>`).join(''));
purpose.innerHTML = '<option value="">Select one</option>' + lists.purposes.map((p) => `<option>${esc(p)}</option>`).join('');
await loadItems();
checkOverdue();

// A doctor's recommendation links here with ?item=12 to open the request form straight away
if (params.get('item')) {
  try {
    const item = await api('/api/equipment/' + Number(params.get('item')));
    if (item.in_stock > 0) openRequest(item, document.querySelector('h1'));
    else showMessage(`${item.name} is out of stock at the moment. Please check again later or ask your doctor about an alternative.`, 'error');
  } catch (err) {
    showMessage(err.message, 'error');
  }
}
