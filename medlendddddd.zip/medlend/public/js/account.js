// "My account" page (every role): update your details and change your password.
import { api, getValues, checkForm, showErrors, clearErrors, showMessage, busy, formatDate, setupPage } from './main.js';

setupPage();

const detailsForm = document.getElementById('details-form');
const passwordForm = document.getElementById('password-form');

// Fill the details form with what is saved
try {
  const profile = await api('/api/profile');
  document.getElementById('username').textContent = profile.username;
  document.getElementById('intro').textContent =
    `${{ admin: 'Equipment desk account', doctor: `Doctor account, ${profile.specialty}`, user: 'Patient account' }[profile.role]}, created ${formatDate(profile.created_at)}.`;
  detailsForm.elements.full_name.value = profile.full_name;
  detailsForm.elements.gender.value = profile.gender;
  detailsForm.elements.phone.value = profile.phone;
} catch (err) {
  showMessage(err.message, 'error');
}

detailsForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  clearErrors(detailsForm);
  const errors = checkForm(detailsForm);
  if (Object.keys(errors).length) return showErrors(detailsForm, errors);

  const done = busy(document.getElementById('details-save'), 'Saving…');
  try {
    const result = await api('/api/profile', 'PUT', getValues(detailsForm));
    document.getElementById('user-name').textContent = detailsForm.elements.full_name.value.trim();
    showMessage(result.message);
  } catch (err) {
    showErrors(detailsForm, err.fields, err.message);
  } finally {
    done();
  }
});

passwordForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  clearErrors(passwordForm);
  const values = getValues(passwordForm);
  const errors = checkForm(passwordForm);
  const strong = values.new_password.length >= 8 && /[A-Za-z]/.test(values.new_password) && /\d/.test(values.new_password);
  if (!errors.new_password && !strong) errors.new_password = 'Password must be at least 8 characters and include a letter and a number.';
  if (!errors.new_password && !errors.confirm_new_password && values.new_password !== values.confirm_new_password) {
    errors.confirm_new_password = 'The passwords do not match.';
  }
  if (Object.keys(errors).length) return showErrors(passwordForm, errors);

  const done = busy(document.getElementById('password-save'), 'Changing password…');
  try {
    const result = await api('/api/profile/password', 'PUT', values);
    passwordForm.reset();
    showMessage(result.message);
  } catch (err) {
    showErrors(passwordForm, err.fields, err.message);
  } finally {
    done();
  }
});
